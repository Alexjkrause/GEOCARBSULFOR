%%% This work is a revision of Bob Berner's Geocarbsulfvolc (GCBSv) model (2006-2009)
%%% By Alex Krause (2019). This is GEOCARBSULFOR as in the paper Krause et
%%% al. (2018) Nat. Comms. but with a few extra changes - namely new uplift
%%% (f_R) and spreading (f_G or f_SR) data, inclusion of uplift in
%%% carbonate weathering, with separate dependencies on the uplift
%%% parameter for carbonate vs. silicate/organic/pyrite weathering, and a
%%% fixed climate sensitivity

clear all

% Globals

global k_wp
global k_wgyp
global k_wg
global k_wc
global kwgypa
global kmgypa
global kwpa
global kmpa
global kwca
global kmca
global kwga
global kmga
global new_kwp
global new_kwgyp
global k_bp
global k_bgyp
global k_p_ya
global k_gyp_ya
global k_g_ya
global k_c_ya
global Rv
global F_wp_a0
global F_wgyp_a0
global F_wg_a0
global F_wc_a0
global F_ws_0
global F_mp_0
global F_ms_0
global Fmg_0
global Fmc_0
global F_wc_y0
global F_bg_0
global F_bo_0
global Xvolc_0
global VNV
global NV
global ACT_si
global ACT_carb
global A0
global O0
global Pyr_0
global Gyp_0
global OA_S_0
global FERT
global J
global n
global temp_0
global Ws
global geocarb_data
global saltzman_data
global new_fR
global updated_reservoirs
global royervolc
global godderis
global gcm
global dynamic_ancients
global COPSE
global timer
global degas

%%% load in spreadsheets

geocarb_data = xlsread('New_Forcings/GEOCARB_input_arrays.xls','','','basic'); % loads in dimensionless parameters, isotopes, and plotting data
saltzman_data = xlsread('New_Forcings/d13C_inputs.xlsx','','','basic'); % loads in Saltzman and Thomas (2012) d13C data
new_fR = xlsread('New_Forcings/usmooth.xlsx','','','basic'); % loads in new f_R data taken from Hay et al. (2006)
degas = xlsread('New_Forcings/mills_brune_degas.xlsx','','','basic'); % loads in new degassing data

%%% turn on/off updates to the original Geocarbsulfvolc model

updated_reservoirs = 'on'; % employ new rate constants and updated equations for the ancient reservoirs
royervolc = 'off'; % uses the Royer et al. values for certain volc-related parameters
gcm = 'on'; % uses Royer et al. values for calculating the gamma aspect of CO2 dependent, climate sensitivity in weathering equations
godderis = 'on'; % uses Godderis et al. data for f_A, f_D, GEOG and f_AW - see eqns file for further info
dynamic_ancients = 'on'; % allows the young to ancient reservoir flux to be dependent on the size of the young reservoir, allowing ancient reservoir sizes to vary
COPSE = 'on'; % Changes the young weathering and burial fluxes of sulphur to COPSE model equations rather than GCBSv


%%% Present Day Values

A0 = 3.193e18; % CO2 in atmosphere and ocean at present
O0 = 3.8e19; % O2 in atmosphere at present
temp_0 = 288; % 15 deg C expressed in Kelvin
Pyr_0 = 12.8571e18; % Present day size of young pyrite reservoir based on Berner's assumption that young pyrite is 1/14th the size of total pyrite, and the COPSE value of 180e18 for total pyrite;
Gyp_0 = 100e18; % Present day size of young gypsum reservoir - COPSE value is 200e18 and is split equally between young and ancient reservoirs;
OA_S_0 = 38e18; % Present day ocean-atmosphere sulphate reservoir


%%% Initial values of reservoirs, used to kick start the model

OA_S = 38e18; % Ocean-atmosphere sulphur
OA_C = 35.5e18; % Ocean-atmosphere carbon - allows the reservoir to reach near present level (in moles) at the end of model run, but the value itself has no effect on RCO2 levels
G_y = 250e18; % Young organic carbon reservoir
G_a = 1000e18; % Ancient organic carbon reservoir
C_y = 1000e18; % Young carbonate reservoir
C_a = 4000e18; % Ancient carbonate reservoir

% The following are the original sizes of sulphur reservoirs in GCBSv
% (unused in the revised model runs)

% Pyr_y = 20e18; % 30e18 value in 1987
% Pyr_a = 280e18; % 220e18 value in 1987
% Gyp_y = 150e18; % 30e18 value in 1987
% Gyp_a = 150e18; % 220e18 value in 1987

% The following are the new sizes of sulphur reservoirs, with gypsum equal to ~25% of total sulphur minus ocean-atmosphere sulphate.
% The total sulphur has been reduced from 638e18 to 418e18 so that the model runs in steady
% state and ends with reservoirs achieving their modern day values

Pyr_y = 20e18; % Young pyrite reservoir
Pyr_a = 260e18; % Ancient pyrite reservoir
Gyp_y = 50e18; % Young gypsum reservoir
Gyp_a = 50e18; % Ancient gypsum reservoir


%%% Rate constants for ancient reservoirs

if strcmp(updated_reservoirs, 'on')
% Berner rate constants for young reservoirs
k_wp = 0.01; % pyrite weathering
k_wgyp = 0.01; % gypsum weathering
k_wg = 0.018; % organic carbon weathering
k_wc = 0.018; % carbonate weathering

% Rate constants for old reservoirs, taken from Zhang et al. (in press?)
kwgypa = 0.0033; % gypsum weathering
kmgypa = 0.0033; % gypsum degassing
kwpa = 0.000893; % pyrite weathering
kmpa = 0.000893; % pyrite degassing
kwca = 0.0005; % carbonate weathering
kmca = 0.001668; % carbonate degassing
kwga = 0.0005; % organic carbon weathering
kmga = 0.00125; % organic carbon degassing

elseif strcmp(updated_reservoirs, 'off')
    % Original GCBSv formulation - ancient reservoirs are instead dependent on present day weathering fluxes
    k_wp = 0.01; % pyrite weathering
    k_wgyp = 0.01; % gypsum weathering
    k_wg = 0.018; % organic carbon weathering
    k_wc = 0.018; % carbonate weathering
end

%%% Rate constants for the new weathering and burial equations for the
%%% sulphur cycle - these are larger than other rate constants as in these
%%% equations we're multiplying by smaller amounts, due to normalisation of
%%% reservoirs

new_kwp = 4.6e17; % young pyrite weathering
new_kwgyp = 1.2e18; % young gypsum weathering
k_bp = 1.15e18; % pyrite burial
k_bgyp = 1.6e18; % gypsum burial

%%% Rate constants which allow the young-ancient flux to vary as a function
%%% of young reservoir size, instead of equalling the combined weathering
%%% plus degassing fluxes of ancient reservoirs

k_p_ya = 0.01; % young-ancient flux for pyrite
k_gyp_ya = 0.01; % young-ancient flux for gypsum
k_g_ya = 0.018; % young-ancient flux for organic carbon
k_c_ya = 0.018; % young-ancient flux for carbonate


%%% Constant parameters

ACT_si = 0.09; % Activation energy for silicates
ACT_carb = 0.087; % Activation energy for carbonates
Ws = 7.4; % Effect of solar insolation on global avg temp
FERT = 0.4; % Proportion of plants that are fertilised by increasing CO2 and affect weathering
J = 4; % Curve fitting parameter representing strength of effect of O2 on d13C fractionation
n = 1.5; % Empirical parameter for d34S fractionation
Rv = 0.704; % Avg value of 87Sr/86Sr of sub-aerial and submarine volcanic rocks
Xvolc_0 = 0.35; % Fraction of total Ca and Mg silicate weathering derived from volcanic rocks at present

%%% Varying various volcanic rock related parameters/fluxes
if strcmp(royervolc, 'on')
% Royer values
VNV = 5; % rate ratio of chemical weathering in volcanic to non-volcanic silicate rocks (called "Wv/Wnv in Berner 2006b)
NV = 0.0075; % arbitrary parameter varying from 0 to 0.015
F_bo_0 = 4e18; % rate of exchange of Ca and Mg between basalt and seawater at present
elseif strcmp(royervolc, 'off')
    VNV = 2; % Berner's standard run rate ratio
    NV = 0.015; % Berner's standard run parameter
    F_bo_0 = 5e18; % Berner's rate of exchange
end

%%% Present day flux values

F_ws_0 = 6.67e18; % Present Si weathering rate
F_wp_a0 = 0.25e18; % Weathering of ancient pyrite
F_wgyp_a0 = 0.5e18; % Weathering of ancient gypsum
F_wg_a0 = 0.5e18; % Weathering of ancient organic carbon
F_wc_a0 = 2e18; % Weathering of ancient carbonate
F_mp_0 = 0.25e18; % Degassing of ancient pyrite
F_ms_0 = 0.5e18; % Degassing of ancient gypsum
Fmg_0 = 1.25e18; % Degassing of ancient organic carbon
Fmc_0 = 6.67e18; % Degassing of ancient carbonates
F_bg_0 = 5e18; % Burial of organic carbon (COPSE model has between 4.5 - 5.5)
F_wc_y0 = 11.35e18; % Weathering of young carbonate (COPSE model has 13.35e18 for total F_wc)


%%% Initial parameters

CO2_SAL = 11; % Rough value at start of Phanerozoic for Geocarbsulf volc
O2_SAL =  1; %0.3; %0.27; %0.198; % 0.6579; % O2_start compared to PAL - lower levels not used here are for other runs, we start with PAL in the revised model to allow for model spin-up


%%% Reservoir starting sizes - to feed into ODE solver

OA_S_start = OA_S;
OA_C_start = OA_C;
Pyr_y_start = Pyr_y;
Pyr_a_start = Pyr_a;
Gyp_y_start = Gyp_y;
Gyp_a_start = Gyp_a;
G_y_start = G_y;
G_a_start = G_a;
C_y_start = C_y;
C_a_start = C_a;

CO2_start = 3.5123e19; % SAL of 11 = 3.193e18 * 11 >> see what SAL is above
O2_start = 3.8e19; %1.14e19; %1.026e19; %3.8e19; %7.524e18; % 2.5e19; % Starting atmospheric O2 levels for 570 Ma, 3.8e19 is 1 PAL


%%% Isotope starting values for reservoirs
St = Pyr_y_start + Pyr_a_start + Gyp_y_start + Gyp_a_start + OA_S_start; % Total sulphur in the system
Ct = G_y_start + G_a_start + C_y_start + C_a_start + OA_C_start; % Total carbon in the system
dlst = 4; % Starting isotope value for total sulphur
dlct = -5.4; % Starting isotope value for total carbon

delta_OA_S_start = 23; % Ocean-atmosphere sulphur isotope value at 570 Ma - 23 for Wu et al., 35.2 for Berner
delta_OA_C_start = -2.011429174; % Ocean-atm carbon at 570 Ma - this is for the Saltzman and Thomas average, use 0 for Berner
delta_p_y_start = 0; % young pyrite
delta_p_a_start = 0; % old pyrite
delta_gyp_y_start = 35; % young gypsum
delta_gyp_a_start = (dlst * St - (delta_p_y_start * Pyr_y_start + delta_gyp_y_start * Gyp_y_start + delta_p_a_start * Pyr_a_start)) / Gyp_a_start; % Calculated ancient gypsum
delta_g_y_start = -23.5; % young organic carbon
delta_g_a_start = -23.5; % old organic carbon
delta_c_y_start = 3; % young carbonate
delta_c_a_start = (dlct * Ct - (delta_g_y_start * G_y_start + delta_c_y_start * C_y_start + delta_g_a_start * G_a_start)) / C_a_start; % Calculated ancient carbonate


%%% Starting values for Sr isotopes of carbonates

R_cy_start = 0.7095; % Average value of 87Sr/86Sr for young carbonates undergoing weathering
R_ca_start = 0.709; % Average value of 87Sr/86Sr for ancient carbonates undergoing weathering


timer = 1; % Show timestep in command window

%%% model timeframe - moves from 570 Ma to present (0)

whenstart = -570;
whenend = 0;

%%% model run - feeds all information into ODE solver, runs for a max time
%%% step of 10 million years

options = odeset('maxstep', 10);
[T,Y] = ode15s(@Geocarbsulfvolc, [whenstart whenend], [OA_S_start  OA_C_start  Pyr_y_start  Pyr_a_start  Gyp_y_start  Gyp_a_start  G_y_start  G_a_start  C_y_start  C_a_start  delta_p_y_start*Pyr_y_start  delta_p_a_start*Pyr_a_start  delta_gyp_y_start*Gyp_y_start  delta_gyp_a_start*Gyp_a_start  delta_g_y_start*G_y_start  delta_g_a_start*G_a_start  delta_c_y_start*C_y_start  delta_c_a_start*C_a_start  O2_start CO2_start 295 2.5e18 0.7e18 CO2_SAL O2_SAL 2.5e18 8e18 3e17 2.5e17 2.5e17 2e17 4e18 5e17 4e18 1.5e18 2e17 5e17 1.25e18 5e18 6.7e18 3.5 3.5 0.75 1 0.6 1 28.7 20 0.63 5e17 1.2e18 0.4e19 1.7e19 delta_p_y_start delta_p_a_start delta_gyp_y_start delta_gyp_a_start delta_g_y_start delta_g_a_start delta_c_y_start delta_c_a_start 0 delta_OA_S_start 24 R_cy_start R_ca_start 1 0], options);


%%% plot figures

figure (1)


subplot(4,5,1)
hold on
plot(T,Y(:,1), 'b')
plot(T,Y(:,2), 'r')
xlabel('Time (Ma)')
ylabel('Ocean-Atm Reservoir')
legend('S', 'C')

subplot(4,5,2)
plot(T,Y(:,3), 'b')
hold on
plot(T,Y(:,4), 'r')
hold on
plot(T,Y(:,5), 'g')
hold on
plot(T,Y(:,6), 'm')
xlabel('Time (Ma)')
ylabel('Sulphur Rock Reservoirs')
legend('Pyr Y', 'Pyr A', 'Gyp Y', 'Gyp A')

subplot(4,5,3)
plot(T,Y(:,7), 'b')
hold on
plot(T,Y(:,8), 'r')
hold on
plot(T,Y(:,9), 'g')
hold on
plot(T,Y(:,10), 'm')
xlabel('Time (Ma)')
ylabel('Carbon Rock Reservoirs')
legend('Org Y', 'Org A', 'Carb Y', 'Carb A')


subplot(4,5,4)
plot(T,Y(:,11), 'b')
hold on
plot(T,Y(:,12), 'r')
hold on
plot(T,Y(:,13), 'g')
hold on
plot(T,Y(:,14), 'm')
xlabel('Time (Ma)')
ylabel('S Isotope Reservoirs')
legend('Pyr Y', 'Pyr A', 'Gyp Y', 'Gyp A')

subplot(4,5,5)
plot(T,Y(:,15), 'b')
hold on
plot(T,Y(:,16), 'r')
hold on
plot(T,Y(:,17), 'g')
hold on
plot(T,Y(:,18), 'm')
xlabel('Time (Ma)')
ylabel('C Isotope Reservoirs')
legend('Org Y', 'Org A', 'Carb Y', 'Carb A')

subplot(4,5,6)
plot(T,Y(:,19), 'b')
xlabel('Time (Ma)')
ylabel('Atmospheric O_2 (mol)')

subplot(4,5,7)
plot(T,Y(:,20), 'k')
ylabel('Atmospheric CO_2 (mol)')

subplot(4,5,8)
plot(T,Y(:,21), 'k')
ylabel('Change in temp (K)')

subplot(4,5,9)
hold on
plot(T,Y(:,22), 'r')
plot(T,Y(:,23), 'm')
plot(T,Y(:,26), 'b')
plot(T,Y(:,27), 'k')
ylabel('Burial Fluxes')
legend('Gyp Burial', 'Pyr Burial', 'Organic Burial', 'Carb Burial')


subplot(4,5,10)
hold on
plot(T,Y(:,28), 'k')
plot(T,Y(:,29), 'b')
plot(T,Y(:,30), 'm')
plot(T,Y(:,31), 'r')
ylabel('Weathering of S reservoirs')
legend('Weather Pyr Y', 'Weather Pyr A', 'Weather Gyp Y', 'Weather Gyp A')

subplot(4,5,11)
hold on
plot(T,Y(:,32), 'k')
plot(T,Y(:,33), 'm')
plot(T,Y(:,34), 'b')
plot(T,Y(:,35), 'r')
ylabel('Weathering of C reservoirs')
legend('Weather Org Y', 'Weather Org A', 'Weather Carb Y', 'Weather Carb A')


subplot(4,5,12)
hold on
plot(T,Y(:,36), 'k')
plot(T,Y(:,37), 'm')
plot(T,Y(:,38), 'b')
plot(T,Y(:,39), 'r')
ylabel('Degassing Fluxes')
legend('Degas Pyr', 'Degas Gyp', 'Degas Org', 'Degas Carb')

subplot(4,5,13)
plot(T,Y(:,40), 'k')
ylabel('Si Weathering')

subplot(4,5,14)
hold on
plot(T,Y(:,41), 'k')
plot(T,Y(:,42), 'm')
ylabel('Weathering Feedback Parameters')
legend('Carb Feedback', 'Si Feedback')

subplot(4,5,15)
hold on
plot(T,Y(:,43), 'k')
plot(T,Y(:,44), 'm')
plot(T,Y(:,45), 'b')
plot(T,Y(:,46), 'r')
plot(T,Y(:,49), 'c')
ylabel('Various parameters')
legend('f C', 'f A', 'f D', 'f R', 'f L')

subplot(4,5,16)
hold on
plot(T,Y(:,47), 'k')
plot(T,Y(:,48), 'm')
ylabel('Isotope Fractionation')
legend('Alpha C', 'Alpha S') 

subplot(4,5,17)
hold on
plot(T,Y(:,50), 'k')
plot(T,Y(:,51), 'm')
plot(T,Y(:,52), 'b')
plot(T,Y(:,53), 'r')
ylabel('Y-A Fluxes')
legend('Pyr', 'Gyp', 'Org', 'Carb')


subplot(4,5,18)
hold on
plot(T,Y(:,54), 'k')
plot(T,Y(:,55), 'm')
plot(T,Y(:,56), 'b')
plot(T,Y(:,57), 'r')
ylabel('S Isotopes')
legend('Pyr Y', 'Pyr A', 'Gyp Y', 'Gyp A')

subplot(4,5,19)
hold on
plot(T,Y(:,58), 'k')
plot(T,Y(:,59), 'm')
plot(T,Y(:,60), 'b')
plot(T,Y(:,61), 'r')
ylabel('C Isotopes')
legend('Org Y', 'Org A', 'Carb Y', 'Carb A')

subplot(4,5,20)
hold on
plot(T,Y(:,62), 'k')
plot(T,Y(:,63), 'm')
ylabel('O-A Isotopes')
legend('Delta C', 'Delta S')

figure (2)

%%%% compare O2 to Berner

subplot(2,1,1)
hold on
%%%% plot berner 2009
plot(geocarb_data(:,1), geocarb_data(:,22),'b')

%%%% plot Royer
plot(geocarb_data(:,1), geocarb_data(:,20), 'm')

%%%% plot model
model_o2_percent = 100.* ( Y(:,25) ./ ( Y(:,25) + 3.762 ) ) ;
plot(T,model_o2_percent, 'k')
xlim([-550 0])
xlabel('Time (Ma)')
ylabel('Atmospheric O_2 (%)')
legend('Berner (2009)', 'Royer et al (2014)', 'GEOCARBSULFOR')

%%%% compare CO2 to Berner

%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
%%%%%% NOTE: BERNER (2008) AND ROYER MODEL CO2 HAS BEEN TRANSFORMED %%%%%%%
%%%%%% TO PAL BY DIVIDING OUTPUT PPM BY 250PPM - ROYER'S %%%%%%%%%%%%%%%%%%
%%%%%% VALUE FOR PRE-HUMAN PRESENT CO2 LEVELS %%%%%%%%%%%%%%%%%%%%%%%%%%%%
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%

subplot(2,1,2)
hold on
%%%% plot Berner volc NV = 0.015 (2008 paper)
plot(geocarb_data(:,1), geocarb_data(:,18), 'b')

%%%% plot Royer
plot(geocarb_data(:,1), geocarb_data(:,19), 'm')

%%%% plot model
plot(T,Y(:,24), 'k')
xlim([-550 0])
xlabel('Time (Ma)')
ylabel('CO2 (PAL)')
legend('Berner (2008)', 'Royer et al (2014)', 'GEOCARBSULFOR')
