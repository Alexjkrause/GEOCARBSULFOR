function dy = Geocarbsulfor(t,y)

%%% Equations underpinning the GEOCARBSULFOR model
%%% By Alex Krause (2018)
%%% Read the frontend for further information

dy = zeros(68,1); % Creates empty matrix to hold data generated

% set globals - pulls in information from the front end

global k_wp
global k_wgyp
global k_wg
global k_wc
global kwgypa
global kmgypa
global kwpa
global kmpa
global kwca
global kmca
global kwga
global kmga
global new_kwp
global new_kwgyp
global k_bp
global k_bgyp
global k_p_ya
global k_gyp_ya
global k_g_ya
global k_c_ya
global Rv
global F_wp_a0
global F_wgyp_a0
global F_wg_a0
global F_wc_a0
global F_ws_0
global F_mp_0
global F_ms_0
global Fmg_0
global Fmc_0
global F_bg_0
global F_wc_y0
global F_bo_0
global Xvolc_0
global VNV
global NV
global Ws
global A0
global O0
global Pyr_0
global Gyp_0
global OA_S_0
global temp_0
global ACT_si
global ACT_carb
global FERT
global J
global n
global geocarb_data
global saltzman_data
global updated_reservoirs
global godderis
global gcm
global dynamic_ancients
global COPSE
global timer


%% Data loaded in %%%%%%%%%%%%%%%%%%%%%
if strcmp(godderis, 'on')
% This loads in the mixture of Godderis et al. (2012) and Royer et al. (2014) 
% dimensionless parameters (normalised to present) at time (t) as used by Royer et al. in their 2014 paper

%Godderis
f_A_forcing = interp1(geocarb_data(:,1), geocarb_data(:,7), t); 
f_A = f_A_forcing; % total land area

%Godderis
f_AW_forcing = interp1(geocarb_data(:,1), geocarb_data(:,9), t); 
f_AW = f_AW_forcing; % fraction of land area experiencing chemical weathering

%Godderis
f_D_forcing = interp1(geocarb_data(:,1), geocarb_data(:,11), t);
f_D = f_D_forcing; % river runoff

%Godderis
GEOG_forcing = interp1(geocarb_data(:,1), geocarb_data(:,13), t); 
GEOG = GEOG_forcing; % effect of change in palaeogeography on temp

%Royer
f_L_forcing = interp1(geocarb_data(:,1), geocarb_data(:,5), t);
f_L = f_L_forcing; % proportion of land area underlain by carbonates

%Royer
f_G_forcing = interp1(geocarb_data(:,1), geocarb_data(:,14), t);
f_G = f_G_forcing; % degassing ratio due to tectonics

elseif strcmp(godderis, 'off')
% This loads in the Berner parameters. 

% Berner 
f_A_forcing = interp1(geocarb_data(:,1), geocarb_data(:,6), t); 
f_A = f_A_forcing; % land area  

% This is the same for Berner and Royer et al.
f_L_forcing = interp1(geocarb_data(:,1), geocarb_data(:,5), t);
f_L = f_L_forcing; % proportion of land area underlain by carbonates

% Berner
f_D_forcing = interp1(geocarb_data(:,1), geocarb_data(:,10), t);
f_D = f_D_forcing; % river runoff

% Berner
GEOG_forcing = interp1(geocarb_data(:,1), geocarb_data(:,12), t); 
GEOG = GEOG_forcing; % Effect of change in palaeogeography on temp

% This is the same for Berner and Royer et al.
f_G_forcing = interp1(geocarb_data(:,1), geocarb_data(:,14), t);
f_G = f_G_forcing; % degassing rate due to tectonics

% This is the fraction of land area experiencing chemical weathering, in
% order to balance the Godderis part of the 'if' function, this data also
% needs to be present, but is actually only a series of 1's
f_AW_forcing = interp1(geocarb_data(:,1), geocarb_data(:,8), t); 
f_AW = f_AW_forcing;

end

%% d34S Isotope data loaded in - choose manually

% Berner d34S data
% delta_OA_S_forcing = interp1(geocarb_data(:,1), geocarb_data(:,15), t);
% delta_OA_S = delta_OA_S_forcing;

% Wu et al d34S data
delta_OA_S_forcing = interp1(geocarb_data(:,1), geocarb_data(:,4), t);
delta_OA_S = delta_OA_S_forcing;

%% d13C Isotope data loaded in - choose manually

% % Berner d13C data
% delta_OA_C_forcing = interp1(geocarb_data(:,1), geocarb_data(:,3), t);
% delta_OA_C = delta_OA_C_forcing;

% Saltzman d13C average
delta_OA_C_forcing = interp1(saltzman_data(:,1), saltzman_data(:,2), t);
delta_OA_C = delta_OA_C_forcing;

% Saltzman d13C drift
% delta_OA_C_forcing = interp1(saltzman_data(:,1), saltzman_data(:,5), t);
% delta_OA_C = delta_OA_C_forcing;


%% f_E %%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
% dependence of weathering rate on soil biological activity due to land plants

LIFE = 0.25;
GYM = 0.875;


if t >= -80
    f_E = 1;
elseif -80 > t && t >= -130
    f_E = (1 - GYM) * ((130 + t) / 50) + GYM;
elseif -130 > t && t >= -350
    f_E = GYM;
elseif -350 > t && t >= -380
    f_E = (GYM - LIFE) * ((380 + t) / 30) + LIFE;
else 
    f_E = LIFE;
end

%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%

%% f_R - mean land elevation (t) / mean land elevation (0)

f_RT = (25.269 * ((t/1000)^3)) + (26.561 * ((t/1000)^2)) + (6.894 * (t/1000)) + 1.063;

f_R = (f_RT / 1.063)^0.67;

%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%



%% f_C variable %%%%%%%%%%%%%%%%%
% dependence of degassing rate on relative proportions of carbonates on shallow platforms or deep ocean

old_f_C = 0.75;

if t >= -150
    f_C = old_f_C + (((1 - old_f_C) / 150) * (150 + t)); 
elseif t < -150
    f_C = old_f_C; 
end


%% Atmospheric CO2 %%%%%%%%%%%%%%%%%

RCO2 = (y(20) / A0); % ratio of CO2atm at time (t) / time (0) - in PAL

%% Atmospheric O2 %%%%%%%%%%%%%%%%%

O2mr = y(19) / O0; % ratio of O2atm at time (t) / time (0) - in PAL

%% f_CO2 - Effect of CO2 on carb and si weathering 

VAS = ((2 * RCO2) / (1 + RCO2))^FERT;
NOVAS = RCO2^0.5;

inter_f_CO2 = interp1([0 -350 -380 -570], [VAS VAS NOVAS NOVAS], t);
f_CO2 = inter_f_CO2;


%% Temp parameter for both carb and si weathering %%%%%%%%%%%%%%%%%
% gamma is response of global mean temp to atmospheric CO2 greenhouse
% effect
if strcmp(gcm, 'on')
    TX = 3;
    glac = 2;

        if 0 > t && t >= -40
            gamma = glac * TX / log(2);
   
        elseif -260 >= t && t >= -330
            gamma = glac * TX / log(2); 
   
        else
            gamma = TX / log(2); 
    
        end
elseif strcmp(gcm, 'off')

        if 0 > t && t >= -40
            gamma = 4;
   
        elseif -260 >= t && t >= -330
            gamma = 4; 
   
        else
            gamma = 3.3; 
    
        end

end
inter_RUN = interp1([0 -40 -260 -340 -570], [0.045 0.045 0.025 0.045 0.025], t);
RUN = inter_RUN; % effect of temperature on global river runoff

temp = (gamma * log(RCO2)) - (Ws * (t/-570)) + GEOG + temp_0; % global average temperature


%% Silicate weathering temp feedback parameter

f_Tsi = exp((ACT_si * (temp - temp_0))) * ((1 + (RUN * (temp - temp_0)))^0.65);


%% Silicate weathering combined temp and CO2 feedback variable

fBsi = f_Tsi * f_CO2;


%% Carbonate weathering temp feedback parameter

f_Tcarb = 1 + (ACT_carb * (temp - temp_0)); % 0.087 is ACT carb


%% Carbonate weathering combined temp and CO2 feedback variable

f_BBcarb = f_Tcarb * f_CO2;


%%%%% Make seafloor spreading rate equal tectonic degassing

f_SR = f_G;

%% Weathering and Degassing Fluxes

if strcmp(updated_reservoirs, 'off')
    %%%% Berner versions
    F_wg_y = f_R * f_A * k_wg * y(7); % Weathering of young organic carbon

    F_wg_a = f_R * F_wg_a0; % Weathering of old organic carbon

    F_wc_y = f_BBcarb * f_L * (f_A * f_D) * f_E * k_wc * y(9); % Weathering of young carbonate

    F_wc_a = f_A * f_D * f_L * f_E * f_BBcarb * F_wc_a0; % Weathering of old carb

    Fmp = f_SR * F_mp_0; % Degassing of old pyrite
    Fms = f_SR * F_ms_0; % Degassing of old gypsum
    Fmg = f_SR * Fmg_0; % Degassing of old organic carbon
    Fmc = f_SR * f_C * Fmc_0; % Degassing of old carbonate

    if strcmp(COPSE, 'off')
    %%%% Berner sulphur equations
    F_wp_y = f_R * f_A * k_wp * y(3); % Weathering of young pyrite

    F_wp_a = f_R * F_wp_a0; % Weathering of old pyrite

    F_wgyp_y = f_A * f_D * k_wgyp * y(5); % Weathering of young gypsum

    F_wgyp_a = f_A * f_D * F_wgyp_a0; % Weathering of old gypsum
    
    elseif strcmp(COPSE, 'on')
    %%%% COPSE sulphur equations
    
    %%% There are two methods by which young pyrite weathering can be
    %%% calculated:
    
    %%% Method 1: Just normalised pyr, plus an oxidative feedback
%     F_wp_y = f_R * f_A * new_kwp * (y(3)/Pyr_0) * (O2mr^0.5); % Weathering of young pyrite
    
    %%% Method 2: COPSE method, dependent on normalised si weathering
    F_wp_y = (y(40)/F_ws_0) * new_kwp * (y(3)/Pyr_0) * (O2mr^0.5); % Weathering of young pyrite

    F_wp_a = f_R * F_wp_a0 * (O2mr^0.5); % Weathering of old pyrite

    F_wgyp_y = (F_wc_y/F_wc_y0) * new_kwgyp * (y(5)/Gyp_0); % Weathering of young gypsum

    F_wgyp_a = f_A * f_D * F_wgyp_a0; % Weathering of old gypsum
    end


elseif strcmp(updated_reservoirs, 'on')
    %%%% New formulations for old reservoirs, where rate constants are multiplied by the reservoir size at each time step
    %%%% instead of using the present day flux of weathering/degassing for that particular reservoir

    F_wg_y = f_R * f_A * k_wg * y(7) * (O2mr^0.5); % Weathering of young organic carbon
 
    F_wg_a = f_R * kwga * y(8) * (O2mr^0.5); % Weathering of old organic carbon

    F_wc_y = f_BBcarb * f_L * (f_A * f_D) * f_E * k_wc * y(9); % Weathering of young carbonate

    F_wc_a = f_BBcarb * f_L * (f_A * f_D) * f_E * kwca * y(10); % Weathering of old carbonate

    Fmp = f_SR * kmpa * y(4); % Degassing of old pyrite
    Fms = f_SR * kmgypa * y(6); % Degassing of old gypsum
    Fmg = f_SR * kmga * y(8); % Degassing of old organic carbon
    Fmc = f_SR * f_C * kmca * y(10); % Degassing of old carbonate
    
    if strcmp(COPSE, 'off')
    % Berner sulphur equations
        F_wp_y = f_R * f_A * k_wp * y(3); % Weathering of young pyrite

        F_wp_a = f_R * kwpa * y(4); % Weathering of old pyrite

        F_wgyp_y = f_A * f_D * k_wgyp * y(5); % Weathering of young gypsum

        F_wgyp_a = f_A * f_D * kwgypa * y(6); % Weathering of old gypsum
    
    elseif strcmp(COPSE, 'on')
    %%%% COPSE sulphur equations
    
    %%% There are two methods by which young pyrite weathering can be
    %%% calculated:
    
    %%% Method 1: Just normalised pyr, plus an oxidative feedback
%       F_wp_y = f_R * f_A * 5.5e17 * (y(3)/Pyr_0) * (O2mr^0.5); % Weathering of young pyrite

    %%% Method 2: COPSE method, dependent on normalised si weathering
        F_wp_y = (y(40)/F_ws_0) * new_kwp * (y(3)/Pyr_0) * (O2mr^0.5); % Weathering of young pyrite

        F_wp_a = f_R * kwpa * y(4) * (O2mr^0.5); % Weathering of old pyrite

        F_wgyp_y = (F_wc_y/F_wc_y0) * new_kwgyp * (y(5)/Gyp_0); % Weathering of young gypsum

        F_wgyp_a = f_A * f_D * kwgypa * y(6); % Weathering of old gypsum

    end

end

%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%

%% Isotope reservoir fluxes

delta_p_y = y(11)/y(3); % young pyrite isotopes
delta_p_a = y(12)/y(4); % ancient pyrite isotopes
delta_gyp_y = y(13)/y(5); % young gypsum isotopes
delta_gyp_a = y(14)/y(6); % ancient gypsum isotopes
delta_g_y = y(15)/y(7); % young organic carbon isotopes
delta_g_a = y(16)/y(8); % ancient organic carbon isotopes
delta_c_y = y(17)/y(9); % young carbonate isotopes
delta_c_a = y(18)/y(10); % ancient carbonate isotopes

pyrite = delta_p_y + delta_p_a; % tracks the combined young and ancient pyrite isotopes

%% Isotope fractionation changes

%%% d13C fractionation equation used in 2008 and 2009, GCBS 2006 uses Hayes
%%% data

alpha_C = 27 + (J * ((y(19)/38e18) - 1)); % d13C fractionation

% alpha_C_forcing = interp1(geocarb_data(:,1), geocarb_data(:,17), t);
% alpha_C = alpha_C_forcing; %  Hayes isotopic fractionation d13C data

alpha_S = 35 * ((y(19)/38e18)^n); % d34S fractionation - this is no longer used in the revised model, it just tracks how it responds to new O2 levels

% alpha_S_forcing = interp1(geocarb_data(:,1), geocarb_data(:,21), t);
% alpha_S = alpha_S_forcing; % Wu et al. (2010) d34S fractionation data


%% Burial fluxes

% Organic carbon burial flux
F_bg = (1/alpha_C) * (((delta_OA_C - delta_c_y) * F_wc_y) + ((delta_OA_C - delta_c_a) * F_wc_a) + ((delta_OA_C - delta_g_y) * F_wg_y) + ((delta_OA_C - delta_g_a) * F_wg_a) + ((delta_OA_C - delta_c_a) * Fmc) + ((delta_OA_C - delta_g_a) * Fmg));


% Carbonate burial flux
F_bc = y(40) + F_wc_y + F_wc_a;


if strcmp(COPSE, 'off')
    %%% Berner equations for pyrite/gypsum burial
    
    % Pyrite burial flux
    F_bp = (1/alpha_S) * (((delta_OA_S - delta_gyp_y) * F_wgyp_y) + ((delta_OA_S - delta_gyp_a) * F_wgyp_a) + ((delta_OA_S - delta_p_y) * F_wp_y) + ((delta_OA_S - delta_p_a) * F_wp_a) + ((delta_OA_S - delta_gyp_a) * Fms) + ((delta_OA_S - delta_p_a) * Fmp)); 
    
    % Gypsum burial flux
    F_bgyp = F_wp_y + F_wgyp_y + F_wp_a + F_wgyp_a + Fms + Fmp - F_bp; % Ocean-atmosphere Sulphur mass balance re-arranged to find F_bgyp - gypsum burial flux

elseif strcmp(COPSE, 'on')
    %%% COPSE equations for pyrite/gypsum burial
    
    load Ca_forcing

    ca_time = -1 .* t_Ca;
    Calc = interp1(ca_time, Ca, t); % This is Horita et al's normalised Ca fluid inclusion data
    
    f_ox = 1/(y(19)/O0); % Oxygen dependent feedback function
    
    % Pyrite burial flux
    F_bp = k_bp * (y(1)/OA_S_0) * f_ox * (F_bg/F_bg_0) ;
    
    % Gypsum burial flux
    F_bgyp = k_bgyp * (y(1)/OA_S_0) * Calc; 
end


%% Young to old reservoir fluxes %%%%%%

if strcmp(dynamic_ancients, 'off')
F_ya_p = F_wp_a + Fmp;
F_ya_gyp = F_wgyp_a + Fms;
F_ya_g = F_wg_a + Fmg;
F_ya_c = F_wc_a + Fmc;
elseif strcmp(dynamic_ancients, 'on')
F_ya_p = y(3) * k_p_ya;
F_ya_gyp = y(5) * k_gyp_ya;
F_ya_g = y(7) * k_g_ya;
F_ya_c = y(9) * k_c_ya;
end

%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%

%% Silicate Weathering

R_ocm_forcing = interp1(geocarb_data(:,1), geocarb_data(:,2), t);
R_ocm = R_ocm_forcing; % Actual Sr isotope data in Royer

Roc = (R_ocm / 10000) + 0.7; % Convert ocean Sr isotope record to 87Sr/86Sr


R_cy = y(65) + ((Roc - y(65)) * (F_bc / y(9))); % Average value of 87Sr/86Sr for young carbonates undergoing weathering

R_ca = y(66) + ((R_cy - y(66)) * (F_ya_c / y(10))); % Average value of 87Sr/86Sr for ancient carbonates undergoing weathering

Rnv = 0.722 - (NV * (1 - f_RT / 1.063)); % Sr fractionation of non-volcanic silicates, 0.717 in 2006, 0.722 in 2008


Xvolc = (((f_SR * F_bo_0 * (Rv - Roc)) + (F_wc_y * R_cy) + (F_wc_a * R_ca) - (Roc * F_bc) + (Rnv * y(40)))) / (y(40) * (Rnv - Rv)); % Fraction of total Ca and Mg silicate weathering derived from volcanic rocks at time (t)

f_volc = ((VNV * Xvolc) + (1 - Xvolc)) / ((VNV * Xvolc_0) + (1 - Xvolc_0)); % volcanic weathering parameter

F_ws = f_volc * fBsi * ((f_AW * f_A * f_D)^0.65) * f_R * f_E * F_ws_0; % Silicate weathering


%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%

%% Mass balance of ocean - atmosphere reservoir

% Ocean-atm sulphur mass balance 

dy(1) = F_wp_y + F_wgyp_y + F_wp_a + F_wgyp_a + Fms + Fmp - F_bp - F_bgyp;


% Ocean-atm carbon mass balance 
dy(2) = F_wg_y + F_wc_y + F_wg_a + F_wc_a + Fmc + Fmg - F_bg - F_bc;


%% Rock reservoirs

dy(3) = F_bp - F_wp_y - F_ya_p; % Young pyrite reservoir

dy(4) = F_ya_p - F_wp_a - Fmp; % Ancient pyrite reservoir

dy(5) = F_bgyp - F_wgyp_y - F_ya_gyp; % Young gypsum reservoir

dy(6) = F_ya_gyp - F_wgyp_a - Fms; % Ancient gypsum reservoir

dy(7) = F_bg - F_wg_y - F_ya_g; % Young organic carbon reservoir

dy(8) = F_ya_g - F_wg_a - Fmg; % Ancient organic carbon reservoir

dy(9) = F_bc - F_wc_y - F_ya_c; % Young carbonate reservoir

dy(10) = F_ya_c - F_wc_a - Fmc; % Ancient carbonate reservoir


%% Isotope mass balance for rock reservoirs

dy(11) = ((delta_OA_S - alpha_S) * F_bp) - (delta_p_y * F_wp_y) - (delta_p_y * F_ya_p); % Young pyrite isotope

dy(12) = (delta_p_y * F_ya_p) - (delta_p_a * F_wp_a) - (delta_p_a * Fmp); % Old pyrite isotope

dy(13) = (delta_OA_S * F_bgyp) - (delta_gyp_y * F_wgyp_y) - (delta_gyp_y * F_ya_gyp); % Young gypsum isotope

dy(14) = (delta_gyp_y * F_ya_gyp) - (delta_gyp_a * F_wgyp_a) - (delta_gyp_a * Fms); % Old gypsum isotope

dy(15) = ((delta_OA_C - alpha_C) * F_bg) - (delta_g_y * F_wg_y) - (delta_g_y * F_ya_g); % Young organic C isotope

dy(16) = (delta_g_y * F_ya_g) - (delta_g_a * F_wg_a) - (delta_g_a * Fmg); % Old organic C isotope

dy(17) = (delta_OA_C * F_bc) - (delta_c_y * F_wc_y) - (delta_c_y * F_ya_c); % Young carbonate isotope

dy(18) = (delta_c_y * F_ya_c) - (delta_c_a * F_wc_a) - (delta_c_a * Fmc); % Old carbonate isotope


%% Atmospheric Oxygen

dy(19) = (F_bg + ((15/8) * F_bp)) - (F_wg_y + F_wg_a + Fmg) - ((15 / 8) * (F_wp_y + F_wp_a + Fmp));

%% Atmospheric CO2

dy(20) = F_wg_y + F_wc_y + F_wg_a + F_wc_a + Fmg + Fmc - F_bg - F_bc;


%% Recording of other fluxes

dy(21) = temp - y(21);

dy(22) = F_bgyp - y(22);

dy(23) = F_bp - y(23);

dy(24) = RCO2 - y(24); % Change in CO2 (PAL)

dy(25) = O2mr - y(25); % Change in O2 (PAL)

dy(26) = F_bg - y(26); 

dy(27) = F_bc - y(27);

dy(28) = F_wp_y - y(28);

dy(29) = F_wp_a - y(29);

dy(30) = F_wgyp_y - y(30);

dy(31) = F_wgyp_a - y(31);

dy(32) = F_wg_y - y(32);

dy(33) = F_wg_a - y(33);

dy(34) = F_wc_y - y(34);

dy(35) = F_wc_a - y(35);

dy(36) = Fmp - y(36);

dy(37) = Fms - y(37);

dy(38) = Fmg - y(38);

dy(39) = Fmc - y(39);

dy(40) = F_ws - y(40);

dy(41) = f_BBcarb - y(41);

dy(42) = fBsi - y(42);

dy(43) = f_C - y(43);

dy(44) = f_A - y(44);

dy(45) = f_D - y(45);

dy(46) = f_R - y(46);

dy(47) = alpha_C - y(47);

dy(48) = alpha_S - y(48);

dy(49) = f_L - y(49);

dy(50) = F_ya_p - y(50);

dy(51) = F_ya_gyp - y(51);

dy(52) = F_ya_g - y(52);

dy(53) = F_ya_c - y(53);

dy(54) = delta_p_y - y(54);

dy(55) = delta_p_a - y(55);

dy(56) = delta_gyp_y - y(56);

dy(57) = delta_gyp_a - y(57);

dy(58) = delta_g_y - y(58);

dy(59) = delta_g_a - y(59);

dy(60) = delta_c_y - y(60);

dy(61) = delta_c_a - y(61);

dy(62) = delta_OA_C - y(62);

dy(63) = delta_OA_S - y(63);

dy(64) = alpha_C - y(64);

dy(65) = R_cy - y(65);

dy(66) = R_ca - y(66);

dy(67) = f_ox - y(67);

dy(68) = pyrite - y(68);

if timer == 1
    t
end



end