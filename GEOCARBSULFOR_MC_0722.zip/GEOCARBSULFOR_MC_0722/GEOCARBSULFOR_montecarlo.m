%%%% Monte Carlo run for Geocarbsulfor 2022

clear mc_outputs
clear mc_params
clear n
clear options
clear stepnumber
clear pars
clear forcings
clear workingstate
clear state
clear rawoutput

n = 5000; % Number of model runs

newtime = -550:1:0;
newtime = newtime';

mc_params.init = 1;
%%% Comment in or out the below depending on whether you want to include
%%% them in your Monte Carlo simulation
mc_params.uplift_mc = 1; % Uplift/erosion rates
mc_params.degas_mc = 1; % Degassing rates
mc_params.c_isotopes_mc = 1; % d13C record
mc_params.J_mc = 1; % The curve fitting parameter in the d13C fractionation equation
mc_params.climate_mc = 1; % Climate sensitivity to CO2 doublings
mc_params.d34sfrac_mc = 1; % The Phanerozoic bounds of d34S fractionation


%% Run Parallel Loop to increase model efficiency 
%(note you can't use global variables within parfor and so monte carlo forcings should be created within GEOCARBSULFOR_frontend_MC if using this approach)
parfor s = 1:n
    disp(s)
    run(s).output = GEOCARBSULFOR_frontend_MC(s,mc_params); % Run GEOCARBSULFOR
end

mc_params_fieldnames = fieldnames(mc_params);
fprintf('------------------------------- \n');
fprintf('Parameters used in Monte Carlo: \n');
disp(mc_params_fieldnames) % Print parameters used in Monte Carlo analysis
clear mc_params_fieldnames
fprintf('------------------------------- \n');

save('mc_runs.mat','run','-v7.3');


%% Process Outputs
fprintf('Processing outputs \n')

state_fields = fieldnames(run(1).output.state);
% Make sure outputs have valid names, ready for adding to a single structure
 
for modelrun = n:-1:1
    for i=1:length(state_fields)
        varName(i) = matlab.lang.makeValidName(string(state_fields(i)));
        grid_outputs.(varName(i))(:,modelrun) = run(modelrun).output.state.(string(state_fields(i)));
%         clear varName
    end
end

% Track how many of the runs ended up as failed runs
allnans = isnan(grid_outputs.O2mr_gridded);
failed_runs = sum(allnans(540,:)); % Generally a model has failed in the spin-up phase

clear run % Remove all state outputs once gridded to save space

grid_fields = fieldnames(grid_outputs);
% Add all gridded outputs to a single structure for cleanliness
fprintf('-------------~ Done ~------------- \n')

fprintf('Creating Output Data Structure \n')

for ni=1:length(grid_fields)
    temps = string(grid_fields(ni));
    tempname = matlab.lang.makeValidName(strsplit(temps,'_gridded'));
    varName(ni) = tempname(1);
    mc_outputs.(varName(ni)) = grid_outputs.(string(grid_fields(ni)));
    % Calculate Max and Min Value at each Time Step for each Variable
    for i=1:length(newtime)
        mc_outputs.max.(varName(ni))(i) = max(grid_outputs.(string(grid_fields(ni)))(i,:));
        mc_outputs.min.(varName(ni))(i) = min(grid_outputs.(string(grid_fields(ni)))(i,:));
    end
    mc_outputs.max.(varName(ni)) = mc_outputs.max.(varName(ni))'; % Flip from row to column for plotting
    mc_outputs.min.(varName(ni)) = mc_outputs.min.(varName(ni))'; % Flip from row to column for plotting
    clear varName temps tempname
end
 
fprintf('-------------~ Done ~------------- \n')

clear grid_outputs % Clear gridded outputs to clean up workspace
 
%% Calculate statistics
fprintf('Calculating statistics \n')

fields = fieldnames(mc_outputs);
fields(ismember(fields,'max')) = []; % Remove from fields cell array to avoid error in subsequent loop (i.e. dont want to calculate mean of the max data values)
fields(ismember(fields,'min')) = []; % Remove from fields cell array to avoid error in subsequent loop

%%% Comment in some of the below if you want further statistics
for ni=1:length(fields)
    varname = string(fields(ni));
%     mc_outputs.CI95.(varname) = ones(length(mc_outputs.(varname)),2);
%     disp(ni)
%     for i = 1:length(mc_outputs.(varname))
    for i = 1:length(newtime)
        x = mc_outputs.(varname)(i,:);
%         SEM = nanstd(x) / sqrt(length(x));      % Standard Error
%         ts = tinv([0.025  0.975], length(x)-1);  % T-Score
%         CI = nanmean(x) + ts * SEM;          % Confidence Intervals
%         mc_outputs.CI95.(varname)(i,:) = CI;
        meanx = nanmean(x);
        medianx = nanmedian(x);
        stdx = nanstd(x);
        mc_outputs.medians.(varname)(i,:) = medianx;
        mc_outputs.means.(varname)(i,:) = meanx;
        mc_outputs.stds.(varname)(i,:) = stdx;
        mc_outputs.min1.(varname)(i,:) = meanx - stdx;
        mc_outputs.plus1.(varname)(i,:) = meanx + stdx;
        clear x meanx stdx medianx %SEM ts CI 
    end
end

%%%% Change some of the data into different units for plotting
CO2ppm = mc_outputs.means.RCO2 .* 280;
CO2_plus = mc_outputs.plus1.RCO2 .* 280;
CO2_minus = mc_outputs.min1.RCO2 .* 280;
CO2_max = mc_outputs.max.RCO2 .* 280;
CO2_min = mc_outputs.min.RCO2 .* 280;

SulphmM = mc_outputs.means.OA_S ./ 0.001 ./ 1.338e21;
Sulph_plus = mc_outputs.plus1.OA_S ./ 0.001 ./ 1.338e21;
Sulph_minus = mc_outputs.min1.OA_S ./ 0.001 ./ 1.338e21;
Sulph_max = mc_outputs.max.OA_S ./ 0.001 ./ 1.338e21;
Sulph_min = mc_outputs.min.OA_S ./ 0.001 ./ 1.338e21;

fprintf('-------------~ Done ~------------- \n')

%% Plot figures
fprintf('Plotting figures \n')

figure
subplot(3,2,1)
hold on
box on
plot(newtime,mc_outputs.means.O2_percent,'k')
plot(newtime,mc_outputs.max.O2_percent,'c')
plot(newtime,mc_outputs.min.O2_percent,'c')
xlim([-550 0])
ylabel('O_2 (% atm)')

subplot(3,2,2)
hold on
box on
plot(newtime,CO2ppm,'k')
plot(newtime,CO2_max,'c')
plot(newtime,CO2_min,'c')
xlim([-550 0])
ylabel('CO_2 (ppm)')

subplot(3,2,3)
hold on
box on
plot(newtime,mc_outputs.means.f_burial_pyr,'k')
plot(newtime,mc_outputs.max.f_burial_pyr,'--k')
plot(newtime,mc_outputs.min.f_burial_pyr,'--k')
plot(newtime,mc_outputs.means.f_equation_pyr,'b')
plot(newtime,mc_outputs.max.f_equation_pyr,'--b')
plot(newtime,mc_outputs.min.f_equation_pyr,'--b')
xlim([-550 0])
ylabel('f_p_y_r')
legend('f_{pyr} burial fluxes','max','minus1','f_{pyr} equation','max','minus1')

subplot(3,2,4)
hold on
box on
plot(newtime,mc_outputs.means.temp_degc,'k')
plot(newtime,mc_outputs.max.temp_degc,'c')
plot(newtime,mc_outputs.min.temp_degc,'c')
xlim([-550 0])
ylabel('Temp (degC)')

subplot(3,2,5)
hold on
box on
plot(newtime,SulphmM,'k')
plot(newtime,Sulph_max,'c')
plot(newtime,Sulph_min,'c')
xlim([-550 0])
xlabel('Time (Ma)')
ylabel('OA Sulphate (mM)')

subplot(3,2,6)
hold on
box on
plot(newtime,mc_outputs.means.delta_OA_S,'k')
plot(newtime,mc_outputs.max.delta_OA_S,'c')
plot(newtime,mc_outputs.min.delta_OA_S,'c')
xlim([-550 0])
xlabel('Time (Ma)')
ylabel('d^3^4S (per mille)')

%%% Plot all O2 outputs at once
figure
hold on
box on
for j = 1:n
    plot(newtime,mc_outputs.O2_percent(:,j))
end
xlim([-550 0])
xlabel('Time (Ma)')
ylabel('pO_2 (% atm)')

%%% Plot all d34S outputs at once
figure
hold on
box on
for j = 1:n
    plot(newtime,mc_outputs.delta_OA_S(:,j))
end
xlim([-550 0])
xlabel('Time (Ma)')
ylabel('d34S')

fprintf('-------------~ Done ~------------- \n')
