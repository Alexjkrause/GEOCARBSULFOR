This folder contains the code and data files required to run the 2022 version of GEOCARBSULFOR.

The files do not need to be moved - they are all in the correct place to be read into the model.

To run the model you need to do so from the GEOCARBSULFOR_montecarlo.m file, but first you will need to 
download MATLAB's parallel computing toolbox and the fuzzy logic toolbox. You can specify how many model
runs you want to conduct.

The GEOCARBSULFOR_frontend_MC.m file includes information about static parameters, reservoir sizes, pulls
the spreadsheet data in, defines the Monte Carlo variables, and contains the ODE solver. It also runs the
post model run processing before passing all the data to the GEOCARBSULFOR_montecarlo.m file for statistical
analyses and figure plotting.

The GEOCARBSULFOR_MC.m file contains all of the equations, including the differential ones, for the model.

Please direct any questions to Alex Krause: a.krause@ucl.ac.uk 
