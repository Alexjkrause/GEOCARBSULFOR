function dy = GEOCARBSULFOR_MC(t,y,mc_params)

%%% Equations underpinning the revision of Bob Berner's Geocarbsulfvolc (GCBSv) model (2006-2009)
%%% By Alex Krause (2023) - see front end file for details on changes - for
%%% the paper: Krause et al (submitted) Modelling sulfate concentrations in the global ocean through Phanerozoic time
%%% Journal of the Geological Society of London

dy = zeros(25,1); % Creates empty matrix to hold data generated

% set globals - pulls in information from the front end

global pars
global forcings
global workingstate
global stepnumber


%% Data loaded in

% This loads in the mixture of Godderis et al. (2012) and Royer et al. (2014) 
% dimensionless parameters (normalised to present) at time (t) as used by Royer et al. in their 2014 paper

%Godderis
f_A_forcing = interp1(forcings.geocarb_data(:,1), forcings.geocarb_data(:,7), t); 
f_A = f_A_forcing; % total land area

%Godderis
f_AW_forcing = interp1(forcings.geocarb_data(:,1), forcings.geocarb_data(:,9), t); 
f_AW = f_AW_forcing; % fraction of land area experiencing chemical weathering

%Godderis
f_D_forcing = interp1(forcings.geocarb_data(:,1), forcings.geocarb_data(:,11), t);
f_D = f_D_forcing; % river runoff

%Godderis
GEOG_forcing = interp1(forcings.geocarb_data(:,1), forcings.geocarb_data(:,13), t); 
GEOG = GEOG_forcing; % effect of change in palaeogeography on temp

%Royer
f_L_forcing = interp1(forcings.geocarb_data(:,1), forcings.geocarb_data(:,5), t);
f_L = f_L_forcing; % proportion of land area underlain by carbonates


% Below are the Berner (2006-2009) parameters if you want to use these instead. 

% % Berner 
% f_A_forcing = interp1(forcings.geocarb_data(:,1), forcings.geocarb_data(:,6), t); 
% f_A = f_A_forcing; % land area  
% 
% % This is the same for Berner and Royer et al.
% f_L_forcing = interp1(forcings.geocarb_data(:,1), forcings.geocarb_data(:,5), t);
% f_L = f_L_forcing; % proportion of land area underlain by carbonates
% 
% % Berner
% f_D_forcing = interp1(forcings.geocarb_data(:,1), forcings.geocarb_data(:,10), t);
% f_D = f_D_forcing;
% 
% % Berner
% GEOG_forcing = interp1(forcings.geocarb_data(:,1), forcings.geocarb_data(:,12), t); 
% GEOG = GEOG_forcing; % Effect of change in palaeogeography on temp
% 
% % This is the fraction of land area experiencing chemical weathering, in
% % order to balance the Godderis part of the 'if' function, this data also
% % needs to be present, but is actually only a series of 1's
% f_AW_forcing = interp1(forcings.geocarb_data(:,1), forcings.geocarb_data(:,8), t); 
% f_AW = f_AW_forcing;


%% Degassing data

if isfield(mc_params,'degas_mc')
f_G_forcing_mc = interp1(forcings.f_G(:,1),forcings.f_G(:,2), t);
end

if isfield(mc_params,'degas_mc') == 1
    f_G = f_G_forcing_mc; % degassing rate due to tectonics
else
    f_G_forcing = interp1(D_force_x, D_force_mid, t);
    f_G = f_G_forcing; % degassing rate due to tectonics
end


%% d34S Isotope data loaded in - choose manually

% Berner d34S data for IMB
% delta_OA_S_forcing = interp1(forcings.geocarb_data(:,1), forcings.geocarb_data(:,15), t);
% delta_OA_S = delta_OA_S_forcing;

% Wu et al d34S data for IMB
% delta_OA_S_forcing = interp1(forcings.geocarb_data(:,1), forcings.geocarb_data(:,4), t);
% delta_OA_S = delta_OA_S_forcing;

% Predicted OA d34S Isotopes
delta_OA_S = y(23) ./ y(1);


%% d13C Isotope data loaded in - choose manually

% % Berner d13C data
% delta_OA_C_forcing = interp1(forcings.geocarb_data(:,1), forcings.geocarb_data(:,3), t);
% delta_OA_C = delta_OA_C_forcing;

% d13C data +/- 1sd for use in Monte Carlo - see frontend to see if it's
% S&T (2012) or C&J (2020)

if isfield(mc_params,'c_isotopes_mc')
delta_OA_C_forcing_mc = interp1(forcings.new_delta_OA_C(:,1), forcings.new_delta_OA_C(:,2), t);
end

if isfield(mc_params,'c_isotopes_mc') == 1
    delta_OA_C = delta_OA_C_forcing_mc;
else
    delta_OA_C_forcing = interp1(forcings.d13C(:,1), forcings.d13C(:,2), t);
    delta_OA_C = delta_OA_C_forcing;
end


%% f_E - dependence of weathering rate on soil biological activity due to land plants

LIFE = 0.25;
GYM = 0.875;

if t >= -80
    f_E = 1;
elseif -80 > t && t >= -130
    f_E = (1 - GYM) * ((130 + t) / 50) + GYM;
elseif -130 > t && t >= -350
    f_E = GYM;
elseif -350 > t && t >= -380
    f_E = (GYM - LIFE) * ((380 + t) / 30) + LIFE;
else 
    f_E = LIFE;
end


%% Different methods for f_R - mean land elevation (t) / mean land elevation (0)

% Method 1 - Equation in Geocarbsulfvolc

% f_RT = (25.269 * ((t/1000)^3)) + (26.561 * ((t/1000)^2)) + (6.894 * (t/1000)) + 1.063;
% 
% f_R = (f_RT / 1.063)^0.67;

% Method 2 - using new data from Hay et al (2006)

if isfield(mc_params,'uplift_mc')
f_R_forcing_mc = interp1(forcings.new_f_R(:,1), forcings.new_f_R(:,2), t);
end

if isfield(mc_params,'uplift_mc') == 1
    f_R = f_R_forcing_mc; % 100myr smoothing of Hay data
else   
f_R_forcing = interp1(forcings.new_fR(:,1), forcings.new_fR(:,2), t);
f_R = f_R_forcing;
end



%% f_C - dependence of degassing rate on relative proportions of carbonates on shallow platforms or deep ocean

old_f_C = 0.75;

if t >= -150
    f_C = old_f_C + (((1 - old_f_C) / 150) * (150 + t)); 
elseif t < -150
    f_C = old_f_C; 
end


%% Atmospheric CO2 

RCO2 = (y(20) / pars.A0); % ratio of CO2atm at time (t) / time (0) - in PAL


%% Atmospheric O2 

O2mr = y(19) / pars.O0; % ratio of O2atm at time (t) / time (0) - in PAL

O2_percent = (O2mr / (O2mr + 3.762)) * 100; % O2 as % of atmosphere by volume


%% f_CO2 - Effect of CO2 on carb and si weathering 

VAS = ((2 * RCO2) / (1 + RCO2))^pars.FERT;
NOVAS = RCO2^0.5;

inter_f_CO2 = interp1([0 -350 -380 -570], [VAS VAS NOVAS NOVAS], t);
f_CO2 = inter_f_CO2;


%% Temp parameter for both carb and si weathering
% gamma is response of global mean temp to atmospheric CO2 greenhouse
% effect, the below is the original GEOCARBSULF variations dependent on
% whether the Earth was in an icehouse or greenhouse period - if you want
% to use these then you need to remove log(2) from the temperature equation

%%% Royer et al. (2014) version
%TX = 3;
%glac = 2;
% 
%if 0 > t && t >= -40
%   gamma = glac * TX / log(2);
%    
%elseif -260 >= t && t >= -330
%   gamma = glac * TX / log(2); 
%    
%else
%   gamma = TX / log(2); 
%     
%end

%%% Berner (2006) version (based on earlier GEOCARBs)
%if 0 > t && t >= -40
%   gamma = 4;
%    
%elseif -260 >= t && t >= -330
%   gamma = 4; 
%    
%else
%   gamma = 3.3; 
%     
%end


if isfield(mc_params,'climate_mc') == 1
    gamma = pars.climate;
else
    gamma = 5; % climate sensitivity is now fixed, and log(2) is directly incorporated into the temp equation
end

inter_RUN = interp1([0 -40 -260 -340 -570], [0.045 0.045 0.025 0.045 0.025], t);
RUN = inter_RUN; % effect of temperature on global river runoff

temp = (gamma * (log(RCO2) / log(2))) - (pars.Ws * (t/-570)) + GEOG + pars.temp_0; % global average temperature


%% Silicate weathering temp feedback parameter

f_Tsi = exp((pars.ACT_si * (temp - pars.temp_0))) * ((1 + (RUN * (temp - pars.temp_0)))^0.65);


%% Silicate weathering combined temp and CO2 feedback variable

fBsi = f_Tsi * f_CO2;


%% Carbonate weathering temp feedback parameter

f_Tcarb = 1 + (pars.ACT_carb * (temp - pars.temp_0)); % 0.087 is ACT carb


%% Carbonate weathering combined temp and CO2 feedback variable

f_BBcarb = f_Tcarb * f_CO2;


%%%%% Make seafloor spreading rate equal tectonic degassing

f_SR = f_G;


%% Sulfur scalings
%%% Used to force gypsum weathering, gypsum burial and pyrite burial at
%%% certain times for Figure 4. Set these equal to 1 when running the
%%% baseline model version

load ('Forcings\exp_and_dep_data.mat') % Loads Bluth and Kump (1991) evaporite data
load ('Forcings\evap_burial.mat') % Loads Babel and Schreiber (2014) evaporite data

wgyp_force = 1;
bgyp_force = 1;

% Use these if using normalised Bluth and Kump data to scale the forcings
% wgyp_force = interp1(time_exposure,normalised_exposure,t);
% bgyp_force = interp1(time_deposition,normalised_deposition,t);

% Use these if using Babel and Schreiber evaporite data to scale the forcings
% wgyp_force = 1;
% bgyp_force = interp1(time_burial,norm_evap_burial,t);


%% Weathering and Degassing Fluxes
%%% Formulations for old reservoirs follow GEOCARBSULFOR, where rate constants are 
%%% multiplied by the reservoir size at each time step instead of using the 
%%% present day flux of weathering/degassing for that particular reservoir

% roll off - decreases O2 sinks as O2 declines
if O2mr > 0
    roll_off = sigmf((log10(O2mr)),[10,-2]);
else
    roll_off = 0;
end

% Degassing - all
Fmp = f_SR * pars.kmpa * y(4) * roll_off; % Degassing of old pyrite

Fms = f_SR * pars.kmgypa * y(6); % Degassing of old gypsum

Fmg = f_SR * pars.kmga * y(8) * roll_off; % Degassing of old organic carbon

Fmc = f_SR * f_C * pars.kmca * y(10); % Degassing of old carbonate


% Weathering - carbon
F_wg_y = f_R^0.33 * f_A * pars.k_wg * y(7) * (O2mr^0.5) * roll_off; % Weathering of young organic carbon
 
F_wg_a = f_R^0.33 * pars.kwga * y(8) * (O2mr^0.5) * roll_off; % Weathering of old organic carbon

F_wc_y = f_BBcarb * f_L * (f_A * f_D) * f_E * pars.k_wc * y(9) * f_R^0.9; % Weathering of young carbonate

F_wc_a = f_BBcarb * f_L * (f_A * f_D) * f_E * pars.kwca * y(10) * f_R^0.9; % Weathering of old carbonate


% Weathering - sulfur

%%% Young pyr weathering, method 1: Normalised pyr - not used this time!
% F_wp_y = f_R^0.33 * f_A * 5.5e17 * (y(3)/pars.Pyr_0) * roll_off; % Weathering of young pyrite
     
%%% Young pyr weathering, method 2: dependent on normalised silicate weathering
F_wp_y = (y(22)/pars.F_ws_0) * pars.new_kwp * (y(3)/pars.Pyr_0) * roll_off; % Weathering of young pyrite

F_wp_a = f_R^0.33 * pars.kwpa * y(4) * roll_off; % Weathering of old pyrite

F_wgyp_y = (F_wc_y/pars.F_wc_y0) * pars.new_kwgyp * (y(5)/pars.Gyp_0) * wgyp_force; % Weathering of young gypsum

F_wgyp_a = f_A * f_D * pars.kwgypa * y(6); % Weathering of old gypsum


%% Isotope reservoir fluxes

delta_p_y = y(11)/y(3); % young pyrite isotopes
delta_p_a = y(12)/y(4); % ancient pyrite isotopes
delta_gyp_y = y(13)/y(5); % young gypsum isotopes
delta_gyp_a = y(14)/y(6); % ancient gypsum isotopes
delta_g_y = y(15)/y(7); % young organic carbon isotopes
delta_g_a = y(16)/y(8); % ancient organic carbon isotopes
delta_c_y = y(17)/y(9); % young carbonate isotopes
delta_c_a = y(18)/y(10); % ancient carbonate isotopes


%% Isotope fractionation changes

%%% d13C fractionation equation used in 2008 and 2009, GCBS 2006 uses Hayes
%%% data

if isfield(mc_params,'J_mc') == 1
    monte_J = pars.J;
else
    monte_J = 4;
end

alpha_C = 27 + (monte_J .* (max((y(19) ./ pars.O0), 0) - 1)); % d13C fractionation


% alpha_C_forcing = interp1(forcings.geocarb_data(:,1), forcings.geocarb_data(:,17), t);
% alpha_C = alpha_C_forcing; %  Hayes isotopic fractionation d13C data


%%%%% d34S fractionation - used for producing d34S of seawater record

% alpha_S = 35 * ((y(19)/pars.O0)^pars.n); % originally used when the S cycle was IMB

% alpha_S_forcing = interp1(forcings.geocarb_data(:,1), forcings.geocarb_data(:,21), t);
% alpha_S = alpha_S_forcing; % Wu et al. (2010) d34S fractionation data

if isfield(mc_params,'d34sfrac_mc') == 1
    alpha_S = pars.d34sfrac;
else
    alpha_S = 32.4;
end % Uses max and min fractionation from the last 570 Ma from Wu et al.

%%%% NOTE - see below for alpha_S using fpyr


%% Burial fluxes

% Organic carbon burial flux
F_bg = (1/alpha_C) * (((delta_OA_C - delta_c_y) * F_wc_y) + ((delta_OA_C - delta_c_a) * F_wc_a) + ((delta_OA_C - delta_g_y) * F_wg_y) + ((delta_OA_C - delta_g_a) * F_wg_a) + ((delta_OA_C - delta_c_a) * Fmc) + ((delta_OA_C - delta_g_a) * Fmg));

F_bg = max(F_bg,0);

% Carbonate burial flux
F_bc = y(22) + F_wc_y + F_wc_a;


%%% Berner equations for pyrite/gypsum burial
% Pyrite burial flux
% F_bp = (1/alpha_S) * (((delta_OA_S - delta_gyp_y) * F_wgyp_y) + ((delta_OA_S - delta_gyp_a) * F_wgyp_a) + ((delta_OA_S - delta_p_y) * F_wp_y) + ((delta_OA_S - delta_p_a) * F_wp_a) + ((delta_OA_S - delta_gyp_a) * Fms) + ((delta_OA_S - delta_p_a) * Fmp)); 
% Gypsum burial flux
% F_bgyp = F_wp_y + F_wgyp_y + F_wp_a + F_wgyp_a + Fms + Fmp - F_bp; % Ocean-atmosphere Sulphur mass balance re-arranged to find F_bgyp - gypsum burial flux
    

%%% COPSE 'forwards' equations for pyrite/gypsum burial

% Pyrite
f_ox = 1/(y(19)/pars.O0); % Oxygen dependent feedback function
F_bp = pars.k_bp * (y(1)/pars.OA_S_0) * f_ox * (F_bg/pars.F_bg_0); % Pyrite burial flux

% Gypsum
%%%% Horita et al. fluid inclusion data normalised - used in GEOCARBSULFOR
% (2018) and in the AREPS (2023) versions
% load ('Forcings\Ca_forcing.mat')
% ca_time = -1 .* t_Ca;
% Calc = interp1(ca_time, Ca, t);

%%%% Weldeghebriel et al. (2022) fluid inclusion data normalised and smoothed
if isfield(mc_params,'ca_conc_mc')
Ca_mc = interp1(forcings.f_Ca(:,1),forcings.f_Ca(:,2), t);
end

if isfield(mc_params,'ca_conc_mc') == 1
    Calc = Ca_mc;
else
    calc_forcing = interp1(time_ca, ca_avg, t);
    Calc = calc_forcing;
end


% Baseline equation for gypsum burial, also used when B&K forcing is used
F_bgyp = pars.k_bgyp * (y(1)/pars.OA_S_0) * Calc * bgyp_force; % Gypsum burial flux


% Use the below if you run the model without any reliance on Ca for gypsum burial

% F_bgyp = pars.k_bgyp * (y(1)/pars.OA_S_0) * bgyp_force; % Gypsum burial flux



% Use the below if using the Babel and Schreiber evaporite data for gypsum
% burial on top of the model calculated gypsum burial

% F_bgyp_inter = interp1(time_burial,evap_burial,t);
% F_bgyp = F_bgyp_inter + pars.k_bgyp * (y(1)/pars.OA_S_0) * Calc;



%% Fraction of burial as pyrite

f_burial_pyr = F_bp / (F_bp + F_bgyp); % Using fluxes

f_equation_pyr = (pars.d34s_in - delta_OA_S) / (-1 * alpha_S); % Using equation from Canfield and Farquhar (2009)

% alpha_S = ((pars.d34s_in - delta_OA_S) / f_burial_pyr) / -1; % Above is
% rearranged to solve for d34S fractionation


%% [SO4]sw residence time

sulf_res_out = y(1) / (F_bp + F_bgyp); % Based on inputs

sulf_res_in = y(1) / (F_wp_y + F_wp_a + F_wgyp_y + F_wgyp_a + Fmp + Fms); % Based on outputs


%% Young to old reservoir fluxes

F_ya_p = y(3) * pars.k_p_ya;
F_ya_gyp = y(5) * pars.k_gyp_ya;
F_ya_g = y(7) * pars.k_g_ya;
F_ya_c = y(9) * pars.k_c_ya;


%% Silicate Weathering

R_ocm_forcing = interp1(forcings.geocarb_data(:,1), forcings.geocarb_data(:,2), t);
R_ocm = R_ocm_forcing; % Actual Sr isotope data in Royer

Roc = (R_ocm / 10000) + 0.7; % Convert ocean Sr isotope record to 87Sr/86Sr

R_cy = y(24) + ((Roc - y(24)) * (F_bc / y(9))); % Average value of 87Sr/86Sr for young carbonates undergoing weathering

R_ca = y(25) + ((R_cy - y(25)) * (F_ya_c / y(10))); % Average value of 87Sr/86Sr for ancient carbonates undergoing weathering

Rnv = 0.722 - (pars.NV * (1 - f_R^0.33)); % Sr fractionation of non-volcanic silicates, 0.717 in 2006, 0.722 in 2008


Xvolc = (((f_SR * pars.F_bo_0 * (pars.Rv - Roc)) + (F_wc_y * R_cy) + (F_wc_a * R_ca) - (Roc * F_bc) + (Rnv * y(22)))) / (y(22) * (Rnv - pars.Rv)); % Fraction of total Ca and Mg silicate weathering derived from volcanic rocks at time (t)

f_volc = ((pars.VNV * Xvolc) + (1 - Xvolc)) / ((pars.VNV * pars.Xvolc_0) + (1 - pars.Xvolc_0)); % volcanic weathering parameter

F_ws = f_volc * fBsi * ((f_AW * f_A * f_D)^0.65) * f_R^0.33 * f_E * pars.F_ws_0; % Silicate weathering


%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%

%% Ocean - atmosphere reservoirs

% Ocean-atm sulphur mass balance 

dy(1) = F_wp_y + F_wgyp_y + F_wp_a + F_wgyp_a + Fms + Fmp - F_bp - F_bgyp;


% Ocean-atm carbon mass balance 
dy(2) = F_wg_y + F_wc_y + F_wg_a + F_wc_a + Fmc + Fmg - F_bg - F_bc;


%% Rock reservoirs

dy(3) = F_bp - F_wp_y - F_ya_p; % Young pyrite reservoir

dy(4) = F_ya_p - F_wp_a - Fmp; % Ancient pyrite reservoir

dy(5) = F_bgyp - F_wgyp_y - F_ya_gyp; % Young gypsum reservoir

dy(6) = F_ya_gyp - F_wgyp_a - Fms; % Ancient gypsum reservoir

dy(7) = F_bg - F_wg_y - F_ya_g; % Young organic carbon reservoir

dy(8) = F_ya_g - F_wg_a - Fmg; % Ancient organic carbon reservoir

dy(9) = F_bc - F_wc_y - F_ya_c; % Young carbonate reservoir

dy(10) = F_ya_c - F_wc_a - Fmc; % Ancient carbonate reservoir


%% Isotope mass balance for rock reservoirs

dy(11) = ((delta_OA_S - alpha_S) * F_bp) - (delta_p_y * F_wp_y) - (delta_p_y * F_ya_p); % Young pyrite isotope

dy(12) = (delta_p_y * F_ya_p) - (delta_p_a * F_wp_a) - (delta_p_a * Fmp); % Old pyrite isotope

dy(13) = (delta_OA_S * F_bgyp) - (delta_gyp_y * F_wgyp_y) - (delta_gyp_y * F_ya_gyp); % Young gypsum isotope

dy(14) = (delta_gyp_y * F_ya_gyp) - (delta_gyp_a * F_wgyp_a) - (delta_gyp_a * Fms); % Old gypsum isotope

dy(15) = ((delta_OA_C - alpha_C) * F_bg) - (delta_g_y * F_wg_y) - (delta_g_y * F_ya_g); % Young organic C isotope

dy(16) = (delta_g_y * F_ya_g) - (delta_g_a * F_wg_a) - (delta_g_a * Fmg); % Old organic C isotope

dy(17) = (delta_OA_C * F_bc) - (delta_c_y * F_wc_y) - (delta_c_y * F_ya_c); % Young carbonate isotope

dy(18) = (delta_c_y * F_ya_c) - (delta_c_a * F_wc_a) - (delta_c_a * Fmc); % Old carbonate isotope


%% Atmospheric Oxygen

dy(19) = (F_bg + ((15/8) * F_bp)) - (F_wg_y + F_wg_a + Fmg) - ((15 / 8) * (F_wp_y + F_wp_a + Fmp));


%% Atmospheric CO2

dy(20) = F_wg_y + F_wc_y + F_wg_a + F_wc_a + Fmg + Fmc - F_bg - F_bc;


%% Recording of other fluxes

dy(21) = temp - y(21);

dy(22) = F_ws - y(22);

dy(23) = ((delta_p_y * F_wp_y) + (delta_p_a * F_wp_a) + (delta_p_a * Fmp) + (delta_gyp_y * F_wgyp_y) + (delta_gyp_a * F_wgyp_a) + (delta_gyp_a * Fms) - ((delta_OA_S - alpha_S) * F_bp) - (delta_OA_S * F_bgyp));

dy(24) = R_cy - y(24);

dy(25) = R_ca - y(25);


%% Printing of workstates

workingstate.OA_S(stepnumber,1) = y(1);
% workingstate.OA_C(stepnumber,1) = y(2);
% workingstate.Pyr_y(stepnumber,1) = y(3);
% workingstate.Pyr_a(stepnumber,1) = y(4);
% workingstate.Gyp_y(stepnumber,1) = y(5);
% workingstate.Gyp_a(stepnumber,1) = y(6);
% workingstate.G_y(stepnumber,1) = y(7);
% workingstate.G_a(stepnumber,1) = y(8);
% workingstate.C_y(stepnumber,1) = y(9);
% workingstate.C_a(stepnumber,1) = y(10);
% workingstate.Pyr_yres_times_iso(stepnumber,1) = y(11);
% workingstate.Pyr_ares_times_iso(stepnumber,1) = y(12);
% workingstate.Gyp_yres_times_iso(stepnumber,1) = y(13);
% workingstate.Gyp_ares_times_iso(stepnumber,1) = y(14);
% workingstate.G_yres_times_iso(stepnumber,1) = y(15);
% workingstate.G_ares_times_iso(stepnumber,1) = y(16);
% workingstate.C_yres_times_iso(stepnumber,1) = y(17);
% workingstate.C_ares_times_iso(stepnumber,1) = y(18);
% workingstate.O2_mol(stepnumber,1) = y(19);
% workingstate.CO2_mol(stepnumber,1) = y(20);

workingstate.RCO2(stepnumber,1) = RCO2;
workingstate.O2mr(stepnumber,1) = O2mr;
workingstate.O2_percent(stepnumber,1) = O2_percent;
workingstate.temp_degc(stepnumber,1) = temp - 273.15;
workingstate.delta_OA_S(stepnumber,1) = delta_OA_S;
workingstate.f_burial_pyr(stepnumber,1) = f_burial_pyr;
workingstate.f_equation_pyr(stepnumber,1) = f_equation_pyr;
workingstate.F_bp(stepnumber,1) = F_bp;
workingstate.F_bgyp(stepnumber,1) = F_bgyp;
workingstate.F_bg(stepnumber,1) = F_bg;
workingstate.f_R(stepnumber,1) = f_R;
workingstate.alpha_S(stepnumber,1) = alpha_S;
workingstate.wgyp_force(stepnumber,1) = wgyp_force;
workingstate.bgyp_force(stepnumber,1) = bgyp_force;
workingstate.sulf_res_in(stepnumber,1) = sulf_res_in;
workingstate.sulf_res_out(stepnumber,1) = sulf_res_out;

workingstate.time(stepnumber,1) = t;

stepnumber = stepnumber + 1 ;

end