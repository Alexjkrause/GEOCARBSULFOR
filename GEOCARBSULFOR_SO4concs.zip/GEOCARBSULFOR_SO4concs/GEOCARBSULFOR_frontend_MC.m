function run = GEOCARBSULFOR_frontend_MC(s,mc_params)

%%% This work is a revision of Bob Berner's Geocarbsulfvolc (GCBSv) model (2006-2009)
%%% By Alex Krause (2023). This is GEOCARBSULFOR as in the paper Mills et
%%% al. (2023) Annual review of Earth and Planetary Sciences, but [Ca]sw
%%% data (used for the gypsum burial flux) have been updated from Horita et
%%% al. (2002) to Weldeghebriel et al. (2022) and this is now included in
%%% the Monte Carlo runs. As a result some of the rate constants (below)
%%% have also been updated so that model results approximately reach
%%% present day levels at the end of the model run.

% Globals

global pars
global forcings
global workingstate
global stepnumber


%%% load in spreadsheets of data

forcings.geocarb_data = xlsread('Forcings/GEOCARB_input_arrays.xls','','','basic'); % loads in dimensionless parameters, isotopes, and plotting data

forcings.d13C = xlsread('Forcings/d13C_Phan_GTS2020_smoothed','','','basic'); % loads in Cramer and Jarvis (2020) d13C data

forcings.new_fR = xlsread('Forcings/Hay_smooth.xlsx','','','basic'); % loads in new f_R data taken from Hay et al. (2006)

load ('Forcings\SCION_fG.mat') % Degassing data from the SCION model Mills et al. (2021)

load ('Forcings\new_ca_forcing.mat') % [Ca] normalised to present and smoothed - original data from Weldeghebriel et al. (2022)


%% Present Day Values

pars.A0 = 3.193e18; % CO2 in atmosphere and ocean at present
pars.O0 = 3.8e19; % O2 in atmosphere at present
pars.temp_0 = 288; % 15 deg C expressed in Kelvin
pars.Pyr_0 = 12.8571e18; % Present day size of young pyrite reservoir based on Berner's assumption that young pyrite is 1/14th the size of total pyrite, and the COPSE value of 180e18 for total pyrite
pars.Gyp_0 = 100e18; % Present day size of young gypsum reservoir - COPSE value is 200e18 and is split equally between young and ancient reservoirs
pars.OA_S_0 = 39e18; % Present day ocean-atmosphere sulfate reservoir, adjusted from previous 38e18 value


%% Initial values of reservoirs, used to kick start the model

pars.OA_S = 39e18; % Ocean-atmosphere sulfur
pars.OA_C = 35.5e18; % Ocean-atmosphere carbon - allows the reservoir to reach near present level (in moles) at the end of model run, but the value itself has no effect on RCO2 levels
pars.G_y = 250e18; % Young organic carbon reservoir
pars.G_a = 1000e18; % Ancient organic carbon reservoir
pars.C_y = 1000e18; % Young carbonate reservoir
pars.C_a = 4000e18; % Ancient carbonate reservoir

% The following are the original sizes of sulfur reservoirs in GCBSv
% (unused in the revised model runs)

% pars.Pyr_y = 20e18; % 30e18 value in 1987
% pars.Pyr_a = 280e18; % 220e18 value in 1987
% pars.Gyp_y = 150e18; % 30e18 value in 1987
% pars.Gyp_a = 150e18; % 220e18 value in 1987

% The following are the new sizes of sulfur reservoirs, with gypsum equal to ~25% of total sulfur minus ocean-atmosphere sulfate.
% The total sulfur has been reduced from 638e18 to 419e18 so that the model runs with total sulfur conserved and ends with 
% reservoirs achieving their modern day values

pars.Pyr_y = 20e18; % Young pyrite reservoir
pars.Pyr_a = 260e18; % Ancient pyrite reservoir
pars.Gyp_y = 50e18; % Young gypsum reservoir
pars.Gyp_a = 50e18; % Ancient gypsum reservoir


%% Rate constants for young reservoirs

% pars.k_wp = 0.01; % pyrite weathering - Berner version with IMB
% pars.k_wgyp = 0.01; % gypsum weathering - Berner version with IMB
pars.k_wg = 0.018; % organic carbon weathering
pars.k_wc = 0.018; % carbonate weathering
% This is used when gypsum weathering and burial are forced using B&K data
% pars.k_wc = 0.022;

% These are used in GEOCARBSULFOR (2023, AREPS)
% pars.new_kwp = 4.6e17; % young pyrite weathering
% pars.new_kwgyp = 1.2e18; % young gypsum weathering

% These are used for the baseline in this study and for when gypsum burial is not partially dependent on the [Ca]sw
pars.new_kwp = 4.6e17; % young pyrite weathering
pars.new_kwgyp = 1e18; % young gypsum weathering

% These are used when gypsum weathering and burial are forced using B&K
% pars.new_kwp = 4.6e17; % young pyrite weathering
% pars.new_kwgyp = 1.15e18; % young gypsum weathering

% Used when Babel and Schreiber evaporite data added on top of model calculated gyp burial
% pars.new_kwp = 4.6e17; % young pyrite weathering
% pars.new_kwgyp = 1.5e18; % young gypsum weathering


%% Rate constants for ancient reservoirs

% Rate constants for old reservoirs for baseline GEOCARBSULFOR
pars.kwgypa = 0.0033; % gypsum weathering
pars.kmgypa = 0.0033; % gypsum degassing
pars.kwpa = 0.000893; % pyrite weathering
pars.kmpa = 0.000893; % pyrite degassing
pars.kwca = 0.0005; % carbonate weathering
pars.kmca = 0.001668; % carbonate degassing
pars.kwga = 0.0005; % organic carbon weathering
pars.kmga = 0.00125; % organic carbon degassing


%% Rate constants for sulfur burial
%%% Rate constants for the weathering and burial equations for the
%%% 'forwards' sulfur cycle - these are larger than other rate constants as 
%%% in these equations we're multiplying by smaller amounts, due to 
%%% normalisation of reservoirs

% These are used in GEOCARBSULFOR (2023, AREPS)
% pars.k_bp = 1.15e18; % pyrite burial
% pars.k_bgyp = 1.6e18; % gypsum burial

% These are used in the baseline Monte Carlo runs for this study
pars.k_bp = 1.25e18; % pyrite burial
pars.k_bgyp = 1.8e18; % gypsum burial

% This is used when gypsum burial is not partially dependent on the [Ca]sw
% pars.k_bp = 1.25e18; % pyrite burial
% pars.k_bgyp = 2.1e18; % gypsum burial

% These are used when gypsum weathering and burial are forced using B&K but
% also when Shields gyp burial data is added on top of model calculated.
% pars.k_bp = 1.25e18; % pyrite burial
% pars.k_bgyp = 1.6e18; % gypsum burial


%% Rate constants for young-ancient transfer
%%% Rate constants which allow the young-ancient flux to vary as a function
%%% of young reservoir size, instead of equalling the combined weathering
%%% plus degassing fluxes of ancient reservoirs

pars.k_p_ya = 0.01; % young-ancient flux for pyrite
pars.k_gyp_ya = 0.01; % young-ancient flux for gypsum
pars.k_g_ya = 0.018; % young-ancient flux for organic carbon
pars.k_c_ya = 0.018; % young-ancient flux for carbonate


%% Constant parameters

pars.ACT_si = 0.09; % Activation energy for silicates
pars.ACT_carb = 0.087; % Activation energy for carbonates
pars.Ws = 7.4; % Effect of solar insolation on global avg temp
pars.FERT = 0.4; % Proportion of plants that are fertilised by increasing CO2 and affect weathering
pars.n = 1.5; % Empirical parameter for d34S fractionation
pars.Rv = 0.704; % Avg value of 87Sr/86Sr of sub-aerial and submarine volcanic rocks
pars.Xvolc_0 = 0.35; % Fraction of total Ca and Mg silicate weathering derived from volcanic rocks at present
pars.d34s_in = 5; % Average input to the ocean - may have varied between 4 and 12 permille


%% Various volcanic rock related parameters/fluxes

pars.VNV = 2; % Berner's standard run rate ratio of chemical weathering in volcanic to non-volcanic silicate rocks (called "Wv/Wnv in Berner 2006b)
pars.NV = 0.015; % Berner's standard arbitrary parameter varying from 0 to 0.015
pars.F_bo_0 = 5e18; % Berner's rate of exchange of Ca and Mg between basalt and seawater at present


%% Present day flux values

pars.F_ws_0 = 6.67e18; % Present Si weathering rate
pars.F_wp_a0 = 0.25e18; % Weathering of ancient pyrite
pars.F_wgyp_a0 = 0.5e18; % Weathering of ancient gypsum
pars.F_wg_a0 = 0.5e18; % Weathering of ancient organic carbon
pars.F_wc_a0 = 2e18; % Weathering of ancient carbonate
pars.F_mp_0 = 0.25e18; % Degassing of ancient pyrite
pars.F_ms_0 = 0.5e18; % Degassing of ancient gypsum
pars.Fmg_0 = 1.25e18; % Degassing of ancient organic carbon
pars.Fmc_0 = 6.67e18; % Degassing of ancient carbonates
pars.F_bg_0 = 5e18; % Burial of organic carbon (COPSE model has between 4.5 - 5.5)
pars.F_wc_y0 = 11.35e18; % Weathering of young carbonate (COPSE model has 13.35e18 for total F_wc)


%% Initial parameters

pars.CO2_SAL = 11; % Rough value at start of Phanerozoic for Geocarbsulf volc
pars.O2_SAL =  1; % O2_start compared to PAL - we start with PAL to allow for model spin-up


%% Reservoir starting sizes - to feed into ODE solver

pars.OA_S_start = pars.OA_S;
pars.OA_C_start = pars.OA_C;
pars.Pyr_y_start = pars.Pyr_y;
pars.Pyr_a_start = pars.Pyr_a;
pars.Gyp_y_start = pars.Gyp_y;
pars.Gyp_a_start = pars.Gyp_a;
pars.G_y_start = pars.G_y;
pars.G_a_start = pars.G_a;
pars.C_y_start = pars.C_y;
pars.C_a_start = pars.C_a;

pars.CO2_start = 3.5123e19; % SAL of 11 = 3.193e18 * 11 >> see what SAL is above
pars.O2_start = 3.8e19; % Starting atmospheric O2 levels for 570 Ma, 3.8e19 is 1 PAL


%% Isotope starting values for reservoirs
pars.St = pars.Pyr_y_start + pars.Pyr_a_start + pars.Gyp_y_start + pars.Gyp_a_start + pars.OA_S_start; % Total sulfur in the system
pars.Ct = pars.G_y_start + pars.G_a_start + pars.C_y_start + pars.C_a_start + pars.OA_C_start; % Total carbon in the system
% pars.dlst = 4; % Starting isotope value for total sulfur - no longer used as the sulfur cycle is not IMB but 'forwards'
pars.dlst = 8; % Starting isotope value for total sulfur
pars.dlct = -5.4; % Starting isotope value for total carbon

pars.delta_OA_S_start = 23; % Ocean-atmosphere sulfur isotope value at 570 Ma - 23 for Wu et al., 35.2 for Berner
pars.delta_OA_C_start = -1; % Ocean-atm carbon at 570 Ma - this is for Cramer and Jarvis, use 0 for Berner - has little effect overall
pars.delta_p_y_start = 0; % young pyrite
pars.delta_p_a_start = 0; % old pyrite
pars.delta_gyp_y_start = 35; % young gypsum
pars.delta_gyp_a_start = (pars.dlst * pars.St - (pars.delta_p_y_start * pars.Pyr_y_start + pars.delta_gyp_y_start * pars.Gyp_y_start + pars.delta_p_a_start * pars.Pyr_a_start)) / pars.Gyp_a_start; % Calculated ancient gypsum
pars.delta_g_y_start = -23.5; % young organic carbon
pars.delta_g_a_start = -23.5; % old organic carbon
pars.delta_c_y_start = 3; % young carbonate
pars.delta_c_a_start = (pars.dlct * pars.Ct - (pars.delta_g_y_start * pars.G_y_start + pars.delta_c_y_start * pars.C_y_start + pars.delta_g_a_start * pars.G_a_start)) / pars.C_a_start; % Calculated ancient carbonate


%% Starting values for Sr isotopes of carbonates

pars.R_cy_start = 0.7095; % Average value of 87Sr/86Sr for young carbonates undergoing weathering
pars.R_ca_start = 0.709; % Average value of 87Sr/86Sr for ancient carbonates undergoing weathering


%% MONTE CARLO INFORMATION 

% Degassing
if isfield(mc_params,'degas_mc') == 1
    f_G_min = D_force_min; % Extract Min Degas
    f_G_max = D_force_max; % Extract Max 
    f_G_time = D_force_x; % Extract Time

    forcings.f_G = ones(length(f_G_time),2); % Create matrix of same size as input forcing to create random forcing
    forcings.f_G(:,1) = f_G_time;
    for ni = 1:length(f_G_min)
        forcings.f_G(ni,2) = f_G_min(ni) + (f_G_max(ni) - f_G_min(ni)) .* rand;
    end
end

% Uplift/erosion
if isfield(mc_params,'uplift_mc') == 1
    f_R_min = forcings.new_fR(:,4); % Extract Min uplift
    f_R_max = forcings.new_fR(:,2); % Extract Max 
    f_R_time = forcings.new_fR(:,1); % Extract Time

    forcings.new_f_R = ones(length(f_R_time),2); % Create matrix of same size as input forcing to create random forcing
    forcings.new_f_R(:,1) = f_R_time;
    for ni = 1:length(f_R_min)
        forcings.new_f_R(ni,2) = f_R_min(ni) + (f_R_max(ni) - f_R_min(ni)) .* rand;
    end
end

% d13C record
if isfield(mc_params,'c_isotopes_mc') == 1
% S&T (2012)
%     delta_OA_C_min = forcings.d13C(:,4); % Extract minus 1SD C isotopes
%     delta_OA_C_max = forcings.d13C(:,3); % Extract plus 1SD
% C&J (2020)
    delta_OA_C_min = forcings.d13C(:,3); % Extract minus 1SD C isotopes
    delta_OA_C_max = forcings.d13C(:,4); % Extract plus 1SD
    delta_OA_C_time = forcings.d13C(:,1); % Extract Time

    forcings.new_delta_OA_C = ones(length(delta_OA_C_time),2); % Create matrix of same size as input forcing to create random forcing
    forcings.new_delta_OA_C(:,1) = delta_OA_C_time;
    for ni = 1:length(delta_OA_C_min)
        forcings.new_delta_OA_C(ni,2) = delta_OA_C_min(ni) + (delta_OA_C_max(ni) - delta_OA_C_min(ni)) .* rand;
    end
end

% Curve fitting parameter
if isfield(mc_params,'J_mc') == 1
    J_min = 2.5;
    J_max = 7.5;
    pars.J = J_min + (J_max - J_min) .* rand;     
end

% Climate sensitivity
if isfield(mc_params,'climate_mc') == 1
    climate_min = 4;
    climate_max = 6;
    pars.climate = climate_min + (climate_max - climate_min) .* rand;
end

% d34S fractionation bounds
if isfield(mc_params,'d34sfrac_mc') == 1
    d34sfrac_min = 16.7;
    d34sfrac_max = 48.1;
    pars.d34sfrac = d34sfrac_min + (d34sfrac_max - d34sfrac_min) .* rand;
end

% [Ca] bounds
if isfield(mc_params,'ca_conc_mc') == 1
    f_Ca_min = ca_low; % Extract Min [Ca]
    f_Ca_max = ca_up; % Extract Max 
    f_Ca_time = time_ca; % Extract Time

    forcings.f_Ca = ones(length(f_Ca_time),2); % Create matrix of same size as input forcing to create random forcing
    forcings.f_Ca(:,1) = f_Ca_time;
    for ni = 1:length(f_Ca_min)
        forcings.f_Ca(ni,2) = f_Ca_min(ni) + (f_Ca_max(ni) - f_Ca_min(ni)) .* rand;
    end
end


%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%

%%%% set stepnumber to 1
stepnumber = 1 ;


%% starting states

pars.startstate(1) = pars.OA_S_start;
pars.startstate(2) = pars.OA_C_start;
pars.startstate(3) = pars.Pyr_y_start;
pars.startstate(4) = pars.Pyr_a_start;
pars.startstate(5) = pars.Gyp_y_start;
pars.startstate(6) = pars.Gyp_a_start;
pars.startstate(7) = pars.G_y_start;
pars.startstate(8) = pars.G_a_start;
pars.startstate(9) = pars.C_y_start;
pars.startstate(10) = pars.C_a_start;
pars.startstate(11) = pars.delta_p_y_start .* pars.Pyr_y_start;
pars.startstate(12) = pars.delta_p_a_start .* pars.Pyr_a_start;
pars.startstate(13) = pars.delta_gyp_y_start .* pars.Gyp_y_start;
pars.startstate(14) = pars.delta_gyp_a_start .* pars.Gyp_a_start;
pars.startstate(15) = pars.delta_g_y_start .* pars.G_y_start;
pars.startstate(16) = pars.delta_g_a_start .* pars.G_a_start;
pars.startstate(17) = pars.delta_c_y_start .* pars.C_y_start;
pars.startstate(18) = pars.delta_c_a_start .* pars.C_a_start;
pars.startstate(19) = pars.O2_start;
pars.startstate(20) = pars.CO2_start;
pars.startstate(21) = 295; % temperature start
pars.startstate(22) = pars.F_ws_0; % F_ws start
pars.startstate(23) = 7.6e20;
pars.startstate(24) = pars.R_cy_start;
pars.startstate(25) = pars.R_ca_start;


% timer = 1; % Show timestep in command window
tic

%% model timeframe - moves from 570 Ma to present (0)

pars.whenstart = -570;
pars.whenend = 0;

%%% model run - feeds all information into ODE solver, runs for a max time
%%% step of 10 million years

options = odeset('maxstep', 10);
[rawoutput.T,rawoutput.Y] = ode15s(@GEOCARBSULFOR_MC, [pars.whenstart pars.whenend], pars.startstate, options, mc_params);



%%   Postprocessing   %%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
%%%%%% takes 'workingstate' from model and turns into 'state' %%%%%%%

%%% size of output 
pars.output_length = length(rawoutput.T) ;
%%%%%%%%%% model finished output to screen
fprintf('Integration finished \t') ; fprintf('Total steps: %d \t' , stepnumber ) ; fprintf('Output steps: %d \n' , pars.output_length ) 
toc

%%%%%%%%% print final model states using final state for each timepoint
%%%%%%%%% during integration
fprintf('assembling state vectors... \t')
tic

%%%% trecords is index of shared values between ode15s output T vector and
%%%% model recorded workingstate t vector
[sharedvals,trecords] = intersect(workingstate.time,rawoutput.T,'stable') ;

%%%%%% assemble output state vectors
field_names = fieldnames(workingstate) ;
for numfields = 1:length(field_names)
    eval([' state.' char( field_names(numfields) ) ' = workingstate.' char( field_names(numfields) ) '(trecords) ; '])
end

%%% Interpolate over timegrid
timegrid = -570:1:0;
timegrid = timegrid';

state_fields = fieldnames(state);
% Interpolate model outputs to set time grid to reduce information saved
for i=1:length(state_fields)
        varName(i) = matlab.lang.makeValidName(string(strcat(state_fields(i),"_gridded")));
        inter_state.(varName(i)) = interp1(state.time,state.(string(state_fields(i))),timegrid);
        inter_state.(varName(i))(1:20) = []; % Removes 570 to 551 Ma spinup results
        clear varName
end

% Add state vectors to individual run structure

run.state = inter_state;

%%%%%% done message
fprintf('Done: ')
endtime = toc ;
fprintf('time (s): %d \n', endtime )


%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
%%%%%%%%%%%%%%%%%   Cleanup workspace   %%%%%%%%%%%%%%%%%%%%%%%%%%%%%
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
clear state
clear stepnumber
clear u
clear numfields
clear trecords
clear finalrecord
clear field_names
clear n
clear veclength
clear xvec
clear yvec
clear endtime
clear workingstate
clear state


end