figure

subplot(2,1,1)
box on
hold on

col_ran = [200 200 200] ./ 255; % Grey colour for proxy data
blue = [19 159 255] ./ 255; % Light blue for MSR band and SCION model
gold = [237 177 32] ./ 255; % Gold for model +/- 1sd
green = [0 127 0] ./ 255; % Green for COPSE Reloaded
purple = [126 47 142] ./ 255; % Purple for GEOCARBSULF (2018)

%% Weldeghebriel et al. (2022) SO4 from fluid inclusions
% Upper and lower ranges
plot([0 0],[28 29],'color',col_ran)
plot([5.55 5.55],[21.3 29.5],'color',col_ran)
plot([5.61 5.61],[21.3 29.5],'color',col_ran)
plot([5.55 5.61],[21.3 21.3],'color',col_ran)
plot([5.55 5.61],[29.5 29.5],'color',col_ran)
plot([7.2 7.2],[18.5 27.1],'color',col_ran)
plot([11.8 11.8],[18.5 27.1],'color',col_ran)
plot([7.2 11.8],[18.5 18.5],'color',col_ran)
plot([7.2 11.8],[27.1 27.1],'color',col_ran)
plot([13.1 13.1],[17.7 26.3],'color',col_ran)
plot([13.81 13.81],[17.7 26.3],'color',col_ran)
plot([13.1 13.81],[17.7 17.7],'color',col_ran)
plot([13.1 13.81],[26.3 26.3],'color',col_ran)
plot([34 34],[12.9 21.8],'color',col_ran)
plot([36 36],[12.9 21.8],'color',col_ran)
plot([34 36],[12.9 12.9],'color',col_ran)
plot([34 36],[21.8 21.8],'color',col_ran)
plot([93.5 93.5],[7.8 16.3],'color',col_ran)
plot([112.2 112.2],[7.8 16.3],'color',col_ran)
plot([93.5 112.2],[7.8 7.8],'color',col_ran)
plot([93.5 112.2],[16.3 16.3],'color',col_ran)
plot([112.2 112.2],[4.7 11.5],'color',col_ran)
plot([121 121],[4.7 11.5],'color',col_ran)
plot([112.2 121],[4.7 4.7],'color',col_ran)
plot([112.2 121],[11.5 11.5],'color',col_ran)
plot([145.5 145.5],[6.4 14.4],'color',col_ran)
plot([155.7 155.7],[6.4 14.4],'color',col_ran)
plot([145.5 155.7],[6.4 6.4],'color',col_ran)
plot([145.5 155.7],[14.4 14.4],'color',col_ran)
plot([200 200],[14.8 21.8],'color',col_ran)
plot([228 228],[13 21.7],'color',col_ran)
plot([237 237],[13 21.7],'color',col_ran)
plot([228 237],[13 13],'color',col_ran)
plot([228 237],[21.7 21.7],'color',col_ran)
plot([240 240],[13.6 22.5],'color',col_ran)
plot([247.2 247.2],[14.2 23.1],'color',col_ran)
plot([251.2 251.2],[14.2 23.1],'color',col_ran)
plot([247.2 251.2],[14.2 14.2],'color',col_ran)
plot([247.2 251.2],[23.1 23.1],'color',col_ran)
plot([251 251],[17.5 26.2],'color',col_ran)
plot([272 272],[13.6 22.3],'color',col_ran)
plot([274 274],[13.6 22.3],'color',col_ran)
plot([272 274],[13.6 13.6],'color',col_ran)
plot([272 274],[22.3 22.3],'color',col_ran)
plot([283 283],[14.9 23.7],'color',col_ran)
plot([290 290],[14.9 23.7],'color',col_ran)
plot([283 290],[14.9 14.9],'color',col_ran)
plot([283 290],[23.7 23.7],'color',col_ran)
plot([305 305],[14.9 21.8],'color',col_ran)
plot([309 309],[14.9 21.8],'color',col_ran)
plot([305 309],[14.9 14.9],'color',col_ran)
plot([305 309],[21.8 21.8],'color',col_ran)
plot([333 333],[8.9 17.6],'color',col_ran)
plot([365 365],[5.8 13.5],'color',col_ran)
plot([383 383],[5.8 13.5],'color',col_ran)
plot([365 383],[5.8 5.8],'color',col_ran)
plot([365 383],[13.5 13.5],'color',col_ran)
plot([417 417],[4.8 11.8],'color',col_ran)
plot([423 423],[4.8 11.8],'color',col_ran)
plot([417 423],[4.8 4.8],'color',col_ran)
plot([417 423],[11.8 11.8],'color',col_ran)
plot([515 515],[4.7 11.6],'color',col_ran)
plot([544 544],[15 23.9],'color',col_ran)

% % Averages
% plot([0 0],[28.5 28.5],'color',green)
% plot([5.55 5.61],[26.3 26.3],'color',green)
% plot([7.2 11.8],[23.8 23.8],'color',green)
% plot([13.1 13.81],[23 23],'color',green)
% plot([34 36],[18.5 18.5],'color',green)
% plot([93.5 112.2],[13.1 13.1],'color',green)
% plot([112.2 121],[8.8 8.8],'color',green)
% plot([145.5 155.7],[11.3 11.3],'color',green)
% plot([200 200],[18.3 18.3],'color',green)
% plot([228 237],[18.5 18.5],'color',green)
% plot([240 240],[19.2 19.2],'color',green)
% plot([247.2 251.2],[19.8 19.8],'color',green)
% plot([251 251],[22.9 22.9],'color',green)
% plot([272 274],[19 19],'color',green)
% plot([283 290],[20.4 20.4],'color',green)
% plot([305 309],[18.4 18.4],'color',green)
% plot([333 333],[14.3 14.3],'color',green)
% plot([365 383],[10.5 10.5],'color',green)
% plot([417 423],[9 9],'color',green)
% plot([515 515],[8.8 8.8],'color',green)
% plot([544 544],[20.6 20.6],'color',green)

% Algeo et al. (2015) +/- 1sd MSR trend method
load ('Plotting\algeo_sulfate.mat')
plot(algeo_min1_time,algeo_min1_sulf,'color',blue)
plot(algeo_plus1_time,algeo_plus1_sulf,'color',blue)

% Sulfate estimates from CAS isotopes
so4_proxy_data = xlsread('Plotting/CAS_proxy.xlsx','','','basic'); 
t_so4 = so4_proxy_data(:,1);
so4 = so4_proxy_data(:,2);

for u = 1:2:length(so4_proxy_data-1)
   plot( [t_so4(u) t_so4(u)] , [so4(u) so4(u+1)], 'Color', green );  
end

% Plot model results
plot(newtime,SulfmM,'k')
plot(newtime,Sulf_max,'color',gold)
plot(newtime,Sulf_min,'color',gold)
xlim([0 550])
set(gca, 'XDir','reverse')
xlabel('Time (Ma)')
ylabel('Ocean Sulfate (mM)')


subplot(2,1,2)
box on
hold on

load ('Plotting\models_proxy_data.mat')

% Plot this model min and max values
plot(newtime,Sulf_max,'color',gold)
plot(newtime,Sulf_min,'color',gold)

% Plot COPSE Reloaded
plot(COPSE_time,COPSE_so4,'color',green)

% Plot GEOCARBSULFOR (2018)
plot(GCBS4_2018_time,GCBS4_2018_so4,'color',purple)

% Plot SCION
plot(SCION_time,SCION_so4,'color',blue)

% Plot this model average
plot(newtime,SulfmM,'k')

xlim([0 550])
set(gca, 'XDir','reverse')
xlabel('Time (Ma)')
ylabel('Ocean Sulfate (mM)')
legend('','','COPSE (2018)','GEOCARBSULFOR (2018)','SCION (2021)','This study')

