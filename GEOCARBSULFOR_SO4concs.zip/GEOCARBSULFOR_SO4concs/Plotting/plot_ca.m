figure

box on
hold on
set(gca, 'LineWidth', 1)

grey = [200 200 200] ./ 255; % Grey colour for proxy data
blue = [19 159 255] ./ 255; % Light blue for MSR band and SCION model
gold = [237 177 32] ./ 255; % Gold for model +/- 1sd
green = [0 127 0] ./ 255; % Green for COPSE Reloaded
purple = [126 47 142] ./ 255; % Purple for GEOCARBSULF (2018)

%% Weldeghebriel et al. (2022) Ca from fluid inclusions
% Upper and lower ranges
yyaxis left

plot([0 0],[11 11],'ob')
plot([5.55 5.55],[7.1 15.3],'-','color',grey)
plot([5.61 5.61],[7.1 15.3],'-','color',grey)
plot([5.55 5.61],[7.1 7.1],'-','color',grey)
plot([5.55 5.61],[15.3 15.3],'-','color',grey)
plot([7.2 7.2],[8.1 16.6],'-','color',grey)
plot([11.8 11.8],[8.1 16.6],'-','color',grey)
plot([7.2 11.8],[8.1 8.1],'-','color',grey)
plot([7.2 11.8],[16.6 16.6],'-','color',grey)
plot([13.1 13.1],[8.5 17.1],'-','color',grey)
plot([13.81 13.81],[8.5 17.1],'-','color',grey)
plot([13.1 13.81],[8.5 8.5],'-','color',grey)
plot([13.1 13.81],[17.1 17.1],'-','color',grey)
plot([34 34],[11.7 20.6],'-','color',grey)
plot([36 36],[11.7 20.6],'-','color',grey)
plot([34 36],[11.7 11.7],'-','color',grey)
plot([34 36],[20.6 20.6],'-','color',grey)
plot([93.5 93.5],[19.1 27.6],'-','color',grey)
plot([112.2 112.2],[19.1 27.6],'-','color',grey)
plot([93.5 112.2],[19.1 19.1],'-','color',grey)
plot([93.5 112.2],[27.6 27.6],'-','color',grey)
plot([112.2 112.2],[32.2 39],'-','color',grey)
plot([121 121],[32.2 39],'-','color',grey)
plot([112.2 121],[32.2 32.2],'-','color',grey)
plot([112.2 121],[39 39],'-','color',grey)
plot([145.5 145.5],[23.3 31.3],'-','color',grey)
plot([155.7 155.7],[23.3 31.3],'-','color',grey)
plot([145.5 155.7],[23.3 23.3],'-','color',grey)
plot([145.5 155.7],[31.3 31.3],'-','color',grey)
plot([200 200],[13.9 20.9],'-','color',grey)
plot([228 228],[11.9 20.7],'-','color',grey)
plot([237 237],[11.9 20.7],'-','color',grey)
plot([228 237],[11.9 11.9],'-','color',grey)
plot([228 237],[20.7 20.7],'-','color',grey)
plot([240 240],[11 20],'-','color',grey)
plot([247.2 247.2],[10.6 19.5],'-','color',grey)
plot([251.2 251.2],[10.6 19.5],'-','color',grey)
plot([247.2 251.2],[10.6 10.6],'-','color',grey)
plot([247.2 251.2],[19.5 19.5],'-','color',grey)
plot([251 251],[8.6 17.2],'-','color',grey)
plot([272 272],[11.5 20.2],'-','color',grey)
plot([274 274],[11.5 20.2],'-','color',grey)
plot([272 274],[11.5 11.5],'-','color',grey)
plot([272 274],[20.2 20.2],'-','color',grey)
plot([283 283],[10.1 19],'-','color',grey)
plot([290 290],[10.1 19],'-','color',grey)
plot([283 290],[10.1 10.1],'-','color',grey)
plot([283 290],[19 19],'-','color',grey)
plot([305 305],[13.9 20.8],'-','color',grey)
plot([309 309],[13.9 20.8],'-','color',grey)
plot([305 309],[13.9 13.9],'-','color',grey)
plot([305 309],[20.8 20.8],'-','color',grey)
plot([333 333],[16.8 25.5],'-','color',grey)
plot([365 365],[25.6 33.3],'-','color',grey)
plot([383 383],[25.6 33.3],'-','color',grey)
plot([365 383],[25.6 25.6],'-','color',grey)
plot([365 383],[33.3 33.3],'-','color',grey)
plot([417 417],[31 35.2],'-','color',grey)
plot([423 423],[31 35.2],'-','color',grey)
plot([417 423],[31 31],'-','color',grey)
plot([417 423],[35.2 35.2],'-','color',grey)
plot([515 515],[32.1 38.9],'-','color',grey)
plot([544 544],[10 18.8],'-','color',grey)

xlim([0 550])
set(gca, 'XDir','reverse')
xlabel('Time (Ma)')
% ylabel('Ocean Calcium (mM)')




