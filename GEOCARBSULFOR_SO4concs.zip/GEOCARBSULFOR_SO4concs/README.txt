This folder contains the code and data files required to run the 2024 version of GEOCARBSULFOR which incorporates new [Ca]sw data for the paper: 

Krause et al (accepted) Modelling sulfate concentrations in the global ocean through Phanerozoic time, Journal of the Geological Society of London

%% The files do not need to be moved - they are all in the correct place to be read into the model. %%%


To run the model you need to do so from the GEOCARBSULFOR_montecarlo.m file, but first you will need to 
download MATLAB's parallel computing toolbox and the fuzzy logic toolbox. You can specify how many model
runs you want to conduct.


The GEOCARBSULFOR_frontend_MC.m file includes information about static parameters, reservoir sizes, pulls
the spreadsheet data in, defines the Monte Carlo variables, and contains the ODE solver. It also runs the
post model run processing before passing all the data to the GEOCARBSULFOR_montecarlo.m file for statistical
analyses and figure plotting.


The GEOCARBSULFOR_MC.m file contains all of the equations, including the differential ones, for the model.


Main_fig_plot.m file plots, essentially, Figure 3 in the main text but with only a few of the other model predictions.


The Forcings folder contains 
- Ca_forcing.mat                        which is the old Horita et al. (2002) normalised [Ca]sw data, not used in this paper
- d13C_inputs.xlsx                      which is the old d13C data from Saltzman and Thomas (2012), not used in this paper
- d13C_Phan_GTS2020_smoothed.xlsx       which is the new d13C data in use (Cramer and Jarvis, 2020)
- evap_burial.mat                       which is the Babel and Schreiber evaporite data turned into a forcing (Scenario 2)
- exp_and_dep_data.mat                  which is the Bluth and Kump exposure and deposition evaporite data normalised (Scenario 1)
- GEOCARB_input_arrays.xlsx             which contains the majority of the normalised forcings (e.g. land area)
- Hay_smooth.xlsx                       which contains the new uplift data
- new_ca_forcing.mat                    which is the new normalised [Ca]sw data in use (Weldeghebriel et al., 2022)
- SCION_fG.mat                          which is the new tectonic degassing data as used by the SCION (Mills et al., 2021) model

The Plotting folder contains
- algeo_sulfate.mat                     which is the MSR trend max and min [SO4]sw data (Algeo et al., 2015)
- CAS_proxy.xlsx                        which contains a compilation of [SO4]sw data from CAS isotopes - see paper for references
- Crockford_S_isotopes.xlsx             contains a compilation of d34S sulfate isotopes from Crockford et al. (2019)
- models_proxy_data.mat                 which has [SO4]sw predictions from COPSE Reloaded (Lenton et al., 2018), GEOCARBSULFOR (Krause et al., 2018) and SCION (Mills et al., 2021)
- plot_ca.m                             this is a script which can be run to plot the [Ca]sw data from Weldeghebriel et al. (2022)



Please direct any questions to Alex Krause: a.j.krause@leeds.ac.uk 
